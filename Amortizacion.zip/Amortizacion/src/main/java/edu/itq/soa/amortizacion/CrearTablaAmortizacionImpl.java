package edu.itq.soa.amortizacion;

import edu.itq.soa.amortizacion.TablaAmortizacionRequestDocument.TablaAmortizacionRequest;
import edu.itq.soa.amortizacion.TablaAmortizacionResponseDocument.TablaAmortizacionResponse.TablaAmortizacion.Amortizacion;
import edu.itq.soa.amortizacion.tools.CalculosAmortizacion;

public class CrearTablaAmortizacionImpl
  extends CrearTablaAmortizacionSkeleton
{
  public TablaAmortizacionResponseDocument crearTablaAmortizacionOperation(TablaAmortizacionRequestDocument tablaAmortizacionRequest)
  {
    TablaAmortizacionRequest tablaRequest = tablaAmortizacionRequest.getTablaAmortizacionRequest();
    double interes = tablaRequest.getInteres();
    double monto = tablaRequest.getMonto();
    int meses = tablaRequest.getMeses();
    String nombres = tablaRequest.getNombres();
    String apellidoPaterno = tablaRequest.getApellidoPaterno();
    String apellidoMaterno = tablaRequest.getApellidoMaterno();
    String email = tablaRequest.getEmail();
    
    TablaAmortizacionResponseDocument doc = TablaAmortizacionResponseDocument.Factory.newInstance();
    TablaAmortizacionResponseDocument.TablaAmortizacionResponse resp = doc.addNewTablaAmortizacionResponse();
    
    double pagoMensual = CalculosAmortizacion.obtenerPagoMensual(meses, interes, monto);
    int[] numsPago = CalculosAmortizacion.crearNumsPago(meses);
    double[] pagosMensuales = CalculosAmortizacion.crearPagosMensuales(meses, pagoMensual);
    double[] balanceActual = CalculosAmortizacion.obtenerBalanceActual(interes, monto, pagosMensuales, meses);
    double[] interesPago = CalculosAmortizacion.obtenerInteresPago(meses, monto, interes, balanceActual);
    double[] principal = CalculosAmortizacion.obtenerPrincipal(meses, pagosMensuales, interesPago);
    double[] interesesTotales = CalculosAmortizacion.obtenerInteresesTotales(interesPago, meses);
    
    resp.setNombres(nombres);
    resp.setApellidoPaterno(apellidoPaterno);
    resp.setApellidoMaterno(apellidoMaterno);
    resp.setEmail(email);
    resp.setPagoMensual(pagoMensual);
    resp.setInteres(CalculosAmortizacion.obtenerInteresaPagar(interesPago, meses));
    
    for(int i = 0; i < meses; i++)
    {
        Amortizacion amort = resp.addNewTablaAmortizacion().addNewAmortizacion();
        amort.setNumPago(numsPago[i]);
        amort.setPagosMensuales(pagosMensuales[i]);
        amort.setInteresPago(interesPago[i]);
        amort.setPrincipal(principal[i]);
        amort.setBalance(balanceActual[i]);
        amort.setInteresesTotales(interesesTotales[i]);
    }
    
    return doc;
  }
}
