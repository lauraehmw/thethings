package edu.itq.soa.amortizacion;

import edu.itq.soa.amortizacion.tools.CalculosAmortizacion;

public class CrearTablaAmortizacionImpl
  extends CrearTablaAmortizacionSkeleton
{
  public TablaAmortizacionResponseDocument crearTablaAmortizacionOperation(TablaAmortizacionRequestDocument tablaAmortizacionRequest)
  {
    double interes = tablaAmortizacionRequest.getTablaAmortizacionRequest().getInteres();
    double monto = tablaAmortizacionRequest.getTablaAmortizacionRequest().getMonto();
    int meses = tablaAmortizacionRequest.getTablaAmortizacionRequest().getMeses();
    String nombres = tablaAmortizacionRequest.getTablaAmortizacionRequest().getNombres();
    String apellidoPaterno = tablaAmortizacionRequest.getTablaAmortizacionRequest().getApellidoPaterno();
    String apellidoMaterno = tablaAmortizacionRequest.getTablaAmortizacionRequest().getApellidoMaterno();
    
    TablaAmortizacionResponseDocument doc = TablaAmortizacionResponseDocument.Factory.newInstance();
    TablaAmortizacionResponseDocument.TablaAmortizacionResponse resp = doc.addNewTablaAmortizacionResponse();
    
    double pagoMensual = CalculosAmortizacion.obtenerPagoMensual(meses, interes, monto);
    double[] pagosMensuales = CalculosAmortizacion.crearPagosMensuales(meses, pagoMensual);
    double[] balanceActual = CalculosAmortizacion.obtenerBalanceActual(interes, monto, pagosMensuales, meses);
    double[] interesPago = CalculosAmortizacion.obtenerInteresPago(meses, monto, interes, balanceActual);
    
    resp.setNombres(nombres);
    resp.setApellidoPaterno(apellidoPaterno);
    resp.setApellidoMaterno(apellidoMaterno);
    
    resp.setPagoMensual(pagoMensual);
    resp.addNewAmortizacion().setNumPagoArray(CalculosAmortizacion.crearNumsPago(meses));
    resp.addNewAmortizacion().setPagosMensualesArray(pagosMensuales);
    resp.addNewAmortizacion().setBalanceArray(balanceActual);
    resp.addNewAmortizacion().setInteresPagoArray(interesPago);
    resp.addNewAmortizacion().setPrincipalArray(CalculosAmortizacion.obtenerPrincipal(meses, pagosMensuales, interesPago));
    resp.addNewAmortizacion().setInteresesTotalesArray(CalculosAmortizacion.obtenerInteresesTotales(interesPago, meses));
    resp.setInteres(CalculosAmortizacion.obtenerInteresaPagar(interesPago, meses));
    
    return doc;
  }
}
