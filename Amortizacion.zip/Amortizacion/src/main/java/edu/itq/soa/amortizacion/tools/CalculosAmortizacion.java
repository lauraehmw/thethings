package edu.itq.soa.amortizacion.tools;


public class CalculosAmortizacion
{
  public static double redondear(double num)
  {
    return Math.round(num * 100.0) / 100.0;
  }
  
  public static double obtenerPagoMensual(int meses, double interes, double monto)
  {
    double pagoMensual = monto * (interes / 100 / 12) / (1 - Math.pow(1 + interes / 100 / 12, -1 * meses));
    pagoMensual = redondear(pagoMensual);
    return pagoMensual;
  }
  
  public static double obtenerInteresaPagar(double[] interesPago, int meses)
  {
    double interesPagar = 0;
    for (int i = 0; i < meses; i++) {
      interesPagar += interesPago[i];
    }
    return redondear(interesPagar);
  }
  
  public static int[] crearNumsPago(int meses)
  {
    int[] numPago = new int[meses];
    for (int i = 1; i <= meses; i++) {
      numPago[(i - 1)] = i;
    }
    return numPago;
  }
  
  public static double[] crearPagosMensuales(int meses, double pagoMensual)
  {
    double[] pagosMensuales = new double[meses];
    for (int i = 0; i < meses; i++) {
      pagosMensuales[i] = pagoMensual;
    }
    return pagosMensuales;
  }
  
  public static double[] obtenerInteresPago(int meses, double monto, double interes, double[] balanceActual)
  {
    double[] interesesPagos = new double[meses];
    double interesaux = interes / 100;
    interesaux /= 12;
    
    interesesPagos[0] = redondear(monto * interesaux);
    for (int i = 1; i < meses; i++) {
      interesesPagos[i] = redondear(balanceActual[(i - 1)] * interesaux);
    }
    return interesesPagos;
  }
  
  public static double[] obtenerPrincipal(int meses, double[] pagosMensuales, double[] interesPago)
  {
    double[] principal = new double[meses];
    for (int i = 0; i < meses; i++) {
      principal[i] = redondear(pagosMensuales[i] - interesPago[i]);
    }
    return principal;
  }
  
  public static double[] obtenerBalanceActual(double interes, double monto, double[] pagosMensuales, int meses)
  {
    double[] balanceCredito = new double[meses];
    
    double interesaux = interes / 100 / 12;
    
    balanceCredito[0] = redondear(monto + monto * interesaux - pagosMensuales[0]);
    for (int i = 1; i < meses; i++) {
      balanceCredito[i] = redondear(balanceCredito[(i - 1)] + balanceCredito[(i - 1)] * interesaux - pagosMensuales[i]);
    }
    return balanceCredito;
  }
  
  public static double[] obtenerInteresesTotales(double[] interesPago, int meses)
  {
    double[] interesesTotales = new double[meses];
    
    interesesTotales[0] = redondear(interesPago[0]);
    for (int i = 1; i < meses; i++) {
      interesesTotales[i] = redondear(interesesTotales[(i - 1)] + interesPago[i]);
    }
    return interesesTotales;
  }
  
  public static void imprimir(double[] thing, int meses)
  {
    for (int i = 0; i < meses; i++) {
      System.out.println(thing[i]);
    }
  }
}
