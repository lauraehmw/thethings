/*
 * An XML document type.
 * Localname: tablaAmortizacionResponse
 * Namespace: http://itq.edu/soa/amortizacion
 * Java type: edu.itq.soa.amortizacion.TablaAmortizacionResponseDocument
 *
 * Automatically generated - do not modify.
 */
package edu.itq.soa.amortizacion;


/**
 * A document containing one tablaAmortizacionResponse(@http://itq.edu/soa/amortizacion) element.
 *
 * This is a complex type.
 */
public interface TablaAmortizacionResponseDocument extends org.apache.xmlbeans.XmlObject
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(TablaAmortizacionResponseDocument.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s998D9A33BD4A964E4A770C7D878B7D8E").resolveHandle("tablaamortizacionresponse2cefdoctype");
    
    /**
     * Gets the "tablaAmortizacionResponse" element
     */
    edu.itq.soa.amortizacion.TablaAmortizacionResponseDocument.TablaAmortizacionResponse getTablaAmortizacionResponse();
    
    /**
     * Sets the "tablaAmortizacionResponse" element
     */
    void setTablaAmortizacionResponse(edu.itq.soa.amortizacion.TablaAmortizacionResponseDocument.TablaAmortizacionResponse tablaAmortizacionResponse);
    
    /**
     * Appends and returns a new empty "tablaAmortizacionResponse" element
     */
    edu.itq.soa.amortizacion.TablaAmortizacionResponseDocument.TablaAmortizacionResponse addNewTablaAmortizacionResponse();
    
    /**
     * An XML tablaAmortizacionResponse(@http://itq.edu/soa/amortizacion).
     *
     * This is a complex type.
     */
    public interface TablaAmortizacionResponse extends org.apache.xmlbeans.XmlObject
    {
        public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
            org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(TablaAmortizacionResponse.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s998D9A33BD4A964E4A770C7D878B7D8E").resolveHandle("tablaamortizacionresponsee156elemtype");
        
        /**
         * Gets the "nombres" element
         */
        java.lang.String getNombres();
        
        /**
         * Gets (as xml) the "nombres" element
         */
        org.apache.xmlbeans.XmlString xgetNombres();
        
        /**
         * Sets the "nombres" element
         */
        void setNombres(java.lang.String nombres);
        
        /**
         * Sets (as xml) the "nombres" element
         */
        void xsetNombres(org.apache.xmlbeans.XmlString nombres);
        
        /**
         * Gets the "apellidoPaterno" element
         */
        java.lang.String getApellidoPaterno();
        
        /**
         * Gets (as xml) the "apellidoPaterno" element
         */
        org.apache.xmlbeans.XmlString xgetApellidoPaterno();
        
        /**
         * Sets the "apellidoPaterno" element
         */
        void setApellidoPaterno(java.lang.String apellidoPaterno);
        
        /**
         * Sets (as xml) the "apellidoPaterno" element
         */
        void xsetApellidoPaterno(org.apache.xmlbeans.XmlString apellidoPaterno);
        
        /**
         * Gets the "apellidoMaterno" element
         */
        java.lang.String getApellidoMaterno();
        
        /**
         * Gets (as xml) the "apellidoMaterno" element
         */
        org.apache.xmlbeans.XmlString xgetApellidoMaterno();
        
        /**
         * Sets the "apellidoMaterno" element
         */
        void setApellidoMaterno(java.lang.String apellidoMaterno);
        
        /**
         * Sets (as xml) the "apellidoMaterno" element
         */
        void xsetApellidoMaterno(org.apache.xmlbeans.XmlString apellidoMaterno);
        
        /**
         * Gets the "email" element
         */
        java.lang.String getEmail();
        
        /**
         * Gets (as xml) the "email" element
         */
        edu.itq.soa.amortizacion.Email xgetEmail();
        
        /**
         * Sets the "email" element
         */
        void setEmail(java.lang.String email);
        
        /**
         * Sets (as xml) the "email" element
         */
        void xsetEmail(edu.itq.soa.amortizacion.Email email);
        
        /**
         * Gets the "pagoMensual" element
         */
        double getPagoMensual();
        
        /**
         * Gets (as xml) the "pagoMensual" element
         */
        org.apache.xmlbeans.XmlDouble xgetPagoMensual();
        
        /**
         * Sets the "pagoMensual" element
         */
        void setPagoMensual(double pagoMensual);
        
        /**
         * Sets (as xml) the "pagoMensual" element
         */
        void xsetPagoMensual(org.apache.xmlbeans.XmlDouble pagoMensual);
        
        /**
         * Gets the "interes" element
         */
        double getInteres();
        
        /**
         * Gets (as xml) the "interes" element
         */
        org.apache.xmlbeans.XmlDouble xgetInteres();
        
        /**
         * Sets the "interes" element
         */
        void setInteres(double interes);
        
        /**
         * Sets (as xml) the "interes" element
         */
        void xsetInteres(org.apache.xmlbeans.XmlDouble interes);
        
        /**
         * Gets the "tablaAmortizacion" element
         */
        edu.itq.soa.amortizacion.TablaAmortizacionResponseDocument.TablaAmortizacionResponse.TablaAmortizacion getTablaAmortizacion();
        
        /**
         * Sets the "tablaAmortizacion" element
         */
        void setTablaAmortizacion(edu.itq.soa.amortizacion.TablaAmortizacionResponseDocument.TablaAmortizacionResponse.TablaAmortizacion tablaAmortizacion);
        
        /**
         * Appends and returns a new empty "tablaAmortizacion" element
         */
        edu.itq.soa.amortizacion.TablaAmortizacionResponseDocument.TablaAmortizacionResponse.TablaAmortizacion addNewTablaAmortizacion();
        
        /**
         * An XML tablaAmortizacion(@http://itq.edu/soa/amortizacion).
         *
         * This is a complex type.
         */
        public interface TablaAmortizacion extends org.apache.xmlbeans.XmlObject
        {
            public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
                org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(TablaAmortizacion.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s998D9A33BD4A964E4A770C7D878B7D8E").resolveHandle("tablaamortizacion09dcelemtype");
            
            /**
             * Gets array of all "amortizacion" elements
             */
            edu.itq.soa.amortizacion.TablaAmortizacionResponseDocument.TablaAmortizacionResponse.TablaAmortizacion.Amortizacion[] getAmortizacionArray();
            
            /**
             * Gets ith "amortizacion" element
             */
            edu.itq.soa.amortizacion.TablaAmortizacionResponseDocument.TablaAmortizacionResponse.TablaAmortizacion.Amortizacion getAmortizacionArray(int i);
            
            /**
             * Returns number of "amortizacion" element
             */
            int sizeOfAmortizacionArray();
            
            /**
             * Sets array of all "amortizacion" element
             */
            void setAmortizacionArray(edu.itq.soa.amortizacion.TablaAmortizacionResponseDocument.TablaAmortizacionResponse.TablaAmortizacion.Amortizacion[] amortizacionArray);
            
            /**
             * Sets ith "amortizacion" element
             */
            void setAmortizacionArray(int i, edu.itq.soa.amortizacion.TablaAmortizacionResponseDocument.TablaAmortizacionResponse.TablaAmortizacion.Amortizacion amortizacion);
            
            /**
             * Inserts and returns a new empty value (as xml) as the ith "amortizacion" element
             */
            edu.itq.soa.amortizacion.TablaAmortizacionResponseDocument.TablaAmortizacionResponse.TablaAmortizacion.Amortizacion insertNewAmortizacion(int i);
            
            /**
             * Appends and returns a new empty value (as xml) as the last "amortizacion" element
             */
            edu.itq.soa.amortizacion.TablaAmortizacionResponseDocument.TablaAmortizacionResponse.TablaAmortizacion.Amortizacion addNewAmortizacion();
            
            /**
             * Removes the ith "amortizacion" element
             */
            void removeAmortizacion(int i);
            
            /**
             * An XML amortizacion(@http://itq.edu/soa/amortizacion).
             *
             * This is a complex type.
             */
            public interface Amortizacion extends org.apache.xmlbeans.XmlObject
            {
                public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
                    org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(Amortizacion.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s998D9A33BD4A964E4A770C7D878B7D8E").resolveHandle("amortizacionaba8elemtype");
                
                /**
                 * Gets the "numPago" element
                 */
                int getNumPago();
                
                /**
                 * Gets (as xml) the "numPago" element
                 */
                org.apache.xmlbeans.XmlInt xgetNumPago();
                
                /**
                 * Sets the "numPago" element
                 */
                void setNumPago(int numPago);
                
                /**
                 * Sets (as xml) the "numPago" element
                 */
                void xsetNumPago(org.apache.xmlbeans.XmlInt numPago);
                
                /**
                 * Gets the "pagosMensuales" element
                 */
                double getPagosMensuales();
                
                /**
                 * Gets (as xml) the "pagosMensuales" element
                 */
                org.apache.xmlbeans.XmlDouble xgetPagosMensuales();
                
                /**
                 * Sets the "pagosMensuales" element
                 */
                void setPagosMensuales(double pagosMensuales);
                
                /**
                 * Sets (as xml) the "pagosMensuales" element
                 */
                void xsetPagosMensuales(org.apache.xmlbeans.XmlDouble pagosMensuales);
                
                /**
                 * Gets the "interesPago" element
                 */
                double getInteresPago();
                
                /**
                 * Gets (as xml) the "interesPago" element
                 */
                org.apache.xmlbeans.XmlDouble xgetInteresPago();
                
                /**
                 * Sets the "interesPago" element
                 */
                void setInteresPago(double interesPago);
                
                /**
                 * Sets (as xml) the "interesPago" element
                 */
                void xsetInteresPago(org.apache.xmlbeans.XmlDouble interesPago);
                
                /**
                 * Gets the "principal" element
                 */
                double getPrincipal();
                
                /**
                 * Gets (as xml) the "principal" element
                 */
                org.apache.xmlbeans.XmlDouble xgetPrincipal();
                
                /**
                 * Sets the "principal" element
                 */
                void setPrincipal(double principal);
                
                /**
                 * Sets (as xml) the "principal" element
                 */
                void xsetPrincipal(org.apache.xmlbeans.XmlDouble principal);
                
                /**
                 * Gets the "balance" element
                 */
                double getBalance();
                
                /**
                 * Gets (as xml) the "balance" element
                 */
                org.apache.xmlbeans.XmlDouble xgetBalance();
                
                /**
                 * Sets the "balance" element
                 */
                void setBalance(double balance);
                
                /**
                 * Sets (as xml) the "balance" element
                 */
                void xsetBalance(org.apache.xmlbeans.XmlDouble balance);
                
                /**
                 * Gets the "interesesTotales" element
                 */
                double getInteresesTotales();
                
                /**
                 * Gets (as xml) the "interesesTotales" element
                 */
                org.apache.xmlbeans.XmlDouble xgetInteresesTotales();
                
                /**
                 * Sets the "interesesTotales" element
                 */
                void setInteresesTotales(double interesesTotales);
                
                /**
                 * Sets (as xml) the "interesesTotales" element
                 */
                void xsetInteresesTotales(org.apache.xmlbeans.XmlDouble interesesTotales);
                
                /**
                 * A factory class with static methods for creating instances
                 * of this type.
                 */
                
                public static final class Factory
                {
                    public static edu.itq.soa.amortizacion.TablaAmortizacionResponseDocument.TablaAmortizacionResponse.TablaAmortizacion.Amortizacion newInstance() {
                      return (edu.itq.soa.amortizacion.TablaAmortizacionResponseDocument.TablaAmortizacionResponse.TablaAmortizacion.Amortizacion) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
                    
                    public static edu.itq.soa.amortizacion.TablaAmortizacionResponseDocument.TablaAmortizacionResponse.TablaAmortizacion.Amortizacion newInstance(org.apache.xmlbeans.XmlOptions options) {
                      return (edu.itq.soa.amortizacion.TablaAmortizacionResponseDocument.TablaAmortizacionResponse.TablaAmortizacion.Amortizacion) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
                    
                    private Factory() { } // No instance of this class allowed
                }
            }
            
            /**
             * A factory class with static methods for creating instances
             * of this type.
             */
            
            public static final class Factory
            {
                public static edu.itq.soa.amortizacion.TablaAmortizacionResponseDocument.TablaAmortizacionResponse.TablaAmortizacion newInstance() {
                  return (edu.itq.soa.amortizacion.TablaAmortizacionResponseDocument.TablaAmortizacionResponse.TablaAmortizacion) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
                
                public static edu.itq.soa.amortizacion.TablaAmortizacionResponseDocument.TablaAmortizacionResponse.TablaAmortizacion newInstance(org.apache.xmlbeans.XmlOptions options) {
                  return (edu.itq.soa.amortizacion.TablaAmortizacionResponseDocument.TablaAmortizacionResponse.TablaAmortizacion) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
                
                private Factory() { } // No instance of this class allowed
            }
        }
        
        /**
         * A factory class with static methods for creating instances
         * of this type.
         */
        
        public static final class Factory
        {
            public static edu.itq.soa.amortizacion.TablaAmortizacionResponseDocument.TablaAmortizacionResponse newInstance() {
              return (edu.itq.soa.amortizacion.TablaAmortizacionResponseDocument.TablaAmortizacionResponse) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
            
            public static edu.itq.soa.amortizacion.TablaAmortizacionResponseDocument.TablaAmortizacionResponse newInstance(org.apache.xmlbeans.XmlOptions options) {
              return (edu.itq.soa.amortizacion.TablaAmortizacionResponseDocument.TablaAmortizacionResponse) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
            
            private Factory() { } // No instance of this class allowed
        }
    }
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static edu.itq.soa.amortizacion.TablaAmortizacionResponseDocument newInstance() {
          return (edu.itq.soa.amortizacion.TablaAmortizacionResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static edu.itq.soa.amortizacion.TablaAmortizacionResponseDocument newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (edu.itq.soa.amortizacion.TablaAmortizacionResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static edu.itq.soa.amortizacion.TablaAmortizacionResponseDocument parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (edu.itq.soa.amortizacion.TablaAmortizacionResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static edu.itq.soa.amortizacion.TablaAmortizacionResponseDocument parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (edu.itq.soa.amortizacion.TablaAmortizacionResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static edu.itq.soa.amortizacion.TablaAmortizacionResponseDocument parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (edu.itq.soa.amortizacion.TablaAmortizacionResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static edu.itq.soa.amortizacion.TablaAmortizacionResponseDocument parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (edu.itq.soa.amortizacion.TablaAmortizacionResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static edu.itq.soa.amortizacion.TablaAmortizacionResponseDocument parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (edu.itq.soa.amortizacion.TablaAmortizacionResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static edu.itq.soa.amortizacion.TablaAmortizacionResponseDocument parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (edu.itq.soa.amortizacion.TablaAmortizacionResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static edu.itq.soa.amortizacion.TablaAmortizacionResponseDocument parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (edu.itq.soa.amortizacion.TablaAmortizacionResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static edu.itq.soa.amortizacion.TablaAmortizacionResponseDocument parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (edu.itq.soa.amortizacion.TablaAmortizacionResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static edu.itq.soa.amortizacion.TablaAmortizacionResponseDocument parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (edu.itq.soa.amortizacion.TablaAmortizacionResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static edu.itq.soa.amortizacion.TablaAmortizacionResponseDocument parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (edu.itq.soa.amortizacion.TablaAmortizacionResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static edu.itq.soa.amortizacion.TablaAmortizacionResponseDocument parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (edu.itq.soa.amortizacion.TablaAmortizacionResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static edu.itq.soa.amortizacion.TablaAmortizacionResponseDocument parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (edu.itq.soa.amortizacion.TablaAmortizacionResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static edu.itq.soa.amortizacion.TablaAmortizacionResponseDocument parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (edu.itq.soa.amortizacion.TablaAmortizacionResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static edu.itq.soa.amortizacion.TablaAmortizacionResponseDocument parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (edu.itq.soa.amortizacion.TablaAmortizacionResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static edu.itq.soa.amortizacion.TablaAmortizacionResponseDocument parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (edu.itq.soa.amortizacion.TablaAmortizacionResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static edu.itq.soa.amortizacion.TablaAmortizacionResponseDocument parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (edu.itq.soa.amortizacion.TablaAmortizacionResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
