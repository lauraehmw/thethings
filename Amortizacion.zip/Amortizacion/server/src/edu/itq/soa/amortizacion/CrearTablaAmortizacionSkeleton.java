/**
 * CrearTablaAmortizacionSkeleton.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.7.8  Built on : May 19, 2018 (07:06:11 BST)
 */
package edu.itq.soa.amortizacion;

/**
 *  CrearTablaAmortizacionSkeleton java skeleton for the axisService
 */
public class CrearTablaAmortizacionSkeleton {
    /**
     * Auto generated method signature
     *
     * @param tablaAmortizacionRequest
     * @return tablaAmortizacionResponse
     */
    public edu.itq.soa.amortizacion.TablaAmortizacionResponseDocument crearTablaAmortizacionOperation(
        edu.itq.soa.amortizacion.TablaAmortizacionRequestDocument tablaAmortizacionRequest) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#crearTablaAmortizacionOperation");
    }
}
