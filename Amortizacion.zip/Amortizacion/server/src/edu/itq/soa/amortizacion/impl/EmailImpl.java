/*
 * XML Type:  email
 * Namespace: http://itq.edu/soa/amortizacion
 * Java type: edu.itq.soa.amortizacion.Email
 *
 * Automatically generated - do not modify.
 */
package edu.itq.soa.amortizacion.impl;
/**
 * An XML email(@http://itq.edu/soa/amortizacion).
 *
 * This is an atomic type that is a restriction of edu.itq.soa.amortizacion.Email.
 */
public class EmailImpl extends org.apache.xmlbeans.impl.values.JavaStringHolderEx implements edu.itq.soa.amortizacion.Email
{
    private static final long serialVersionUID = 1L;
    
    public EmailImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType, false);
    }
    
    protected EmailImpl(org.apache.xmlbeans.SchemaType sType, boolean b)
    {
        super(sType, b);
    }
}
