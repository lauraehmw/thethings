/*
 * An XML document type.
 * Localname: tablaAmortizacionResponse
 * Namespace: http://itq.edu/soa/amortizacion
 * Java type: edu.itq.soa.amortizacion.TablaAmortizacionResponseDocument
 *
 * Automatically generated - do not modify.
 */
package edu.itq.soa.amortizacion.impl;
/**
 * A document containing one tablaAmortizacionResponse(@http://itq.edu/soa/amortizacion) element.
 *
 * This is a complex type.
 */
public class TablaAmortizacionResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements edu.itq.soa.amortizacion.TablaAmortizacionResponseDocument
{
    private static final long serialVersionUID = 1L;
    
    public TablaAmortizacionResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName TABLAAMORTIZACIONRESPONSE$0 = 
        new javax.xml.namespace.QName("http://itq.edu/soa/amortizacion", "tablaAmortizacionResponse");
    
    
    /**
     * Gets the "tablaAmortizacionResponse" element
     */
    public edu.itq.soa.amortizacion.TablaAmortizacionResponseDocument.TablaAmortizacionResponse getTablaAmortizacionResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            edu.itq.soa.amortizacion.TablaAmortizacionResponseDocument.TablaAmortizacionResponse target = null;
            target = (edu.itq.soa.amortizacion.TablaAmortizacionResponseDocument.TablaAmortizacionResponse)get_store().find_element_user(TABLAAMORTIZACIONRESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "tablaAmortizacionResponse" element
     */
    public void setTablaAmortizacionResponse(edu.itq.soa.amortizacion.TablaAmortizacionResponseDocument.TablaAmortizacionResponse tablaAmortizacionResponse)
    {
        generatedSetterHelperImpl(tablaAmortizacionResponse, TABLAAMORTIZACIONRESPONSE$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "tablaAmortizacionResponse" element
     */
    public edu.itq.soa.amortizacion.TablaAmortizacionResponseDocument.TablaAmortizacionResponse addNewTablaAmortizacionResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            edu.itq.soa.amortizacion.TablaAmortizacionResponseDocument.TablaAmortizacionResponse target = null;
            target = (edu.itq.soa.amortizacion.TablaAmortizacionResponseDocument.TablaAmortizacionResponse)get_store().add_element_user(TABLAAMORTIZACIONRESPONSE$0);
            return target;
        }
    }
    /**
     * An XML tablaAmortizacionResponse(@http://itq.edu/soa/amortizacion).
     *
     * This is a complex type.
     */
    public static class TablaAmortizacionResponseImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements edu.itq.soa.amortizacion.TablaAmortizacionResponseDocument.TablaAmortizacionResponse
    {
        private static final long serialVersionUID = 1L;
        
        public TablaAmortizacionResponseImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName NOMBRES$0 = 
            new javax.xml.namespace.QName("http://itq.edu/soa/amortizacion", "nombres");
        private static final javax.xml.namespace.QName APELLIDOPATERNO$2 = 
            new javax.xml.namespace.QName("http://itq.edu/soa/amortizacion", "apellidoPaterno");
        private static final javax.xml.namespace.QName APELLIDOMATERNO$4 = 
            new javax.xml.namespace.QName("http://itq.edu/soa/amortizacion", "apellidoMaterno");
        private static final javax.xml.namespace.QName EMAIL$6 = 
            new javax.xml.namespace.QName("http://itq.edu/soa/amortizacion", "email");
        private static final javax.xml.namespace.QName PAGOMENSUAL$8 = 
            new javax.xml.namespace.QName("http://itq.edu/soa/amortizacion", "pagoMensual");
        private static final javax.xml.namespace.QName INTERES$10 = 
            new javax.xml.namespace.QName("http://itq.edu/soa/amortizacion", "interes");
        private static final javax.xml.namespace.QName TABLAAMORTIZACION$12 = 
            new javax.xml.namespace.QName("http://itq.edu/soa/amortizacion", "tablaAmortizacion");
        
        
        /**
         * Gets the "nombres" element
         */
        public java.lang.String getNombres()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NOMBRES$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target.getStringValue();
            }
        }
        
        /**
         * Gets (as xml) the "nombres" element
         */
        public org.apache.xmlbeans.XmlString xgetNombres()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlString target = null;
                target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(NOMBRES$0, 0);
                return target;
            }
        }
        
        /**
         * Sets the "nombres" element
         */
        public void setNombres(java.lang.String nombres)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NOMBRES$0, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(NOMBRES$0);
                }
                target.setStringValue(nombres);
            }
        }
        
        /**
         * Sets (as xml) the "nombres" element
         */
        public void xsetNombres(org.apache.xmlbeans.XmlString nombres)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlString target = null;
                target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(NOMBRES$0, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(NOMBRES$0);
                }
                target.set(nombres);
            }
        }
        
        /**
         * Gets the "apellidoPaterno" element
         */
        public java.lang.String getApellidoPaterno()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(APELLIDOPATERNO$2, 0);
                if (target == null)
                {
                    return null;
                }
                return target.getStringValue();
            }
        }
        
        /**
         * Gets (as xml) the "apellidoPaterno" element
         */
        public org.apache.xmlbeans.XmlString xgetApellidoPaterno()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlString target = null;
                target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(APELLIDOPATERNO$2, 0);
                return target;
            }
        }
        
        /**
         * Sets the "apellidoPaterno" element
         */
        public void setApellidoPaterno(java.lang.String apellidoPaterno)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(APELLIDOPATERNO$2, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(APELLIDOPATERNO$2);
                }
                target.setStringValue(apellidoPaterno);
            }
        }
        
        /**
         * Sets (as xml) the "apellidoPaterno" element
         */
        public void xsetApellidoPaterno(org.apache.xmlbeans.XmlString apellidoPaterno)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlString target = null;
                target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(APELLIDOPATERNO$2, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(APELLIDOPATERNO$2);
                }
                target.set(apellidoPaterno);
            }
        }
        
        /**
         * Gets the "apellidoMaterno" element
         */
        public java.lang.String getApellidoMaterno()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(APELLIDOMATERNO$4, 0);
                if (target == null)
                {
                    return null;
                }
                return target.getStringValue();
            }
        }
        
        /**
         * Gets (as xml) the "apellidoMaterno" element
         */
        public org.apache.xmlbeans.XmlString xgetApellidoMaterno()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlString target = null;
                target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(APELLIDOMATERNO$4, 0);
                return target;
            }
        }
        
        /**
         * Sets the "apellidoMaterno" element
         */
        public void setApellidoMaterno(java.lang.String apellidoMaterno)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(APELLIDOMATERNO$4, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(APELLIDOMATERNO$4);
                }
                target.setStringValue(apellidoMaterno);
            }
        }
        
        /**
         * Sets (as xml) the "apellidoMaterno" element
         */
        public void xsetApellidoMaterno(org.apache.xmlbeans.XmlString apellidoMaterno)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlString target = null;
                target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(APELLIDOMATERNO$4, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(APELLIDOMATERNO$4);
                }
                target.set(apellidoMaterno);
            }
        }
        
        /**
         * Gets the "email" element
         */
        public java.lang.String getEmail()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(EMAIL$6, 0);
                if (target == null)
                {
                    return null;
                }
                return target.getStringValue();
            }
        }
        
        /**
         * Gets (as xml) the "email" element
         */
        public edu.itq.soa.amortizacion.Email xgetEmail()
        {
            synchronized (monitor())
            {
                check_orphaned();
                edu.itq.soa.amortizacion.Email target = null;
                target = (edu.itq.soa.amortizacion.Email)get_store().find_element_user(EMAIL$6, 0);
                return target;
            }
        }
        
        /**
         * Sets the "email" element
         */
        public void setEmail(java.lang.String email)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(EMAIL$6, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(EMAIL$6);
                }
                target.setStringValue(email);
            }
        }
        
        /**
         * Sets (as xml) the "email" element
         */
        public void xsetEmail(edu.itq.soa.amortizacion.Email email)
        {
            synchronized (monitor())
            {
                check_orphaned();
                edu.itq.soa.amortizacion.Email target = null;
                target = (edu.itq.soa.amortizacion.Email)get_store().find_element_user(EMAIL$6, 0);
                if (target == null)
                {
                    target = (edu.itq.soa.amortizacion.Email)get_store().add_element_user(EMAIL$6);
                }
                target.set(email);
            }
        }
        
        /**
         * Gets the "pagoMensual" element
         */
        public double getPagoMensual()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PAGOMENSUAL$8, 0);
                if (target == null)
                {
                    return 0.0;
                }
                return target.getDoubleValue();
            }
        }
        
        /**
         * Gets (as xml) the "pagoMensual" element
         */
        public org.apache.xmlbeans.XmlDouble xgetPagoMensual()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlDouble target = null;
                target = (org.apache.xmlbeans.XmlDouble)get_store().find_element_user(PAGOMENSUAL$8, 0);
                return target;
            }
        }
        
        /**
         * Sets the "pagoMensual" element
         */
        public void setPagoMensual(double pagoMensual)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PAGOMENSUAL$8, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(PAGOMENSUAL$8);
                }
                target.setDoubleValue(pagoMensual);
            }
        }
        
        /**
         * Sets (as xml) the "pagoMensual" element
         */
        public void xsetPagoMensual(org.apache.xmlbeans.XmlDouble pagoMensual)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlDouble target = null;
                target = (org.apache.xmlbeans.XmlDouble)get_store().find_element_user(PAGOMENSUAL$8, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.XmlDouble)get_store().add_element_user(PAGOMENSUAL$8);
                }
                target.set(pagoMensual);
            }
        }
        
        /**
         * Gets the "interes" element
         */
        public double getInteres()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(INTERES$10, 0);
                if (target == null)
                {
                    return 0.0;
                }
                return target.getDoubleValue();
            }
        }
        
        /**
         * Gets (as xml) the "interes" element
         */
        public org.apache.xmlbeans.XmlDouble xgetInteres()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlDouble target = null;
                target = (org.apache.xmlbeans.XmlDouble)get_store().find_element_user(INTERES$10, 0);
                return target;
            }
        }
        
        /**
         * Sets the "interes" element
         */
        public void setInteres(double interes)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(INTERES$10, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(INTERES$10);
                }
                target.setDoubleValue(interes);
            }
        }
        
        /**
         * Sets (as xml) the "interes" element
         */
        public void xsetInteres(org.apache.xmlbeans.XmlDouble interes)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlDouble target = null;
                target = (org.apache.xmlbeans.XmlDouble)get_store().find_element_user(INTERES$10, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.XmlDouble)get_store().add_element_user(INTERES$10);
                }
                target.set(interes);
            }
        }
        
        /**
         * Gets the "tablaAmortizacion" element
         */
        public edu.itq.soa.amortizacion.TablaAmortizacionResponseDocument.TablaAmortizacionResponse.TablaAmortizacion getTablaAmortizacion()
        {
            synchronized (monitor())
            {
                check_orphaned();
                edu.itq.soa.amortizacion.TablaAmortizacionResponseDocument.TablaAmortizacionResponse.TablaAmortizacion target = null;
                target = (edu.itq.soa.amortizacion.TablaAmortizacionResponseDocument.TablaAmortizacionResponse.TablaAmortizacion)get_store().find_element_user(TABLAAMORTIZACION$12, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * Sets the "tablaAmortizacion" element
         */
        public void setTablaAmortizacion(edu.itq.soa.amortizacion.TablaAmortizacionResponseDocument.TablaAmortizacionResponse.TablaAmortizacion tablaAmortizacion)
        {
            generatedSetterHelperImpl(tablaAmortizacion, TABLAAMORTIZACION$12, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
        }
        
        /**
         * Appends and returns a new empty "tablaAmortizacion" element
         */
        public edu.itq.soa.amortizacion.TablaAmortizacionResponseDocument.TablaAmortizacionResponse.TablaAmortizacion addNewTablaAmortizacion()
        {
            synchronized (monitor())
            {
                check_orphaned();
                edu.itq.soa.amortizacion.TablaAmortizacionResponseDocument.TablaAmortizacionResponse.TablaAmortizacion target = null;
                target = (edu.itq.soa.amortizacion.TablaAmortizacionResponseDocument.TablaAmortizacionResponse.TablaAmortizacion)get_store().add_element_user(TABLAAMORTIZACION$12);
                return target;
            }
        }
        /**
         * An XML tablaAmortizacion(@http://itq.edu/soa/amortizacion).
         *
         * This is a complex type.
         */
        public static class TablaAmortizacionImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements edu.itq.soa.amortizacion.TablaAmortizacionResponseDocument.TablaAmortizacionResponse.TablaAmortizacion
        {
            private static final long serialVersionUID = 1L;
            
            public TablaAmortizacionImpl(org.apache.xmlbeans.SchemaType sType)
            {
                super(sType);
            }
            
            private static final javax.xml.namespace.QName AMORTIZACION$0 = 
                new javax.xml.namespace.QName("http://itq.edu/soa/amortizacion", "amortizacion");
            
            
            /**
             * Gets array of all "amortizacion" elements
             */
            public edu.itq.soa.amortizacion.TablaAmortizacionResponseDocument.TablaAmortizacionResponse.TablaAmortizacion.Amortizacion[] getAmortizacionArray()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    java.util.List targetList = new java.util.ArrayList();
                    get_store().find_all_element_users(AMORTIZACION$0, targetList);
                    edu.itq.soa.amortizacion.TablaAmortizacionResponseDocument.TablaAmortizacionResponse.TablaAmortizacion.Amortizacion[] result = new edu.itq.soa.amortizacion.TablaAmortizacionResponseDocument.TablaAmortizacionResponse.TablaAmortizacion.Amortizacion[targetList.size()];
                    targetList.toArray(result);
                    return result;
                }
            }
            
            /**
             * Gets ith "amortizacion" element
             */
            public edu.itq.soa.amortizacion.TablaAmortizacionResponseDocument.TablaAmortizacionResponse.TablaAmortizacion.Amortizacion getAmortizacionArray(int i)
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    edu.itq.soa.amortizacion.TablaAmortizacionResponseDocument.TablaAmortizacionResponse.TablaAmortizacion.Amortizacion target = null;
                    target = (edu.itq.soa.amortizacion.TablaAmortizacionResponseDocument.TablaAmortizacionResponse.TablaAmortizacion.Amortizacion)get_store().find_element_user(AMORTIZACION$0, i);
                    if (target == null)
                    {
                      throw new IndexOutOfBoundsException();
                    }
                    return target;
                }
            }
            
            /**
             * Returns number of "amortizacion" element
             */
            public int sizeOfAmortizacionArray()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    return get_store().count_elements(AMORTIZACION$0);
                }
            }
            
            /**
             * Sets array of all "amortizacion" element  WARNING: This method is not atomicaly synchronized.
             */
            public void setAmortizacionArray(edu.itq.soa.amortizacion.TablaAmortizacionResponseDocument.TablaAmortizacionResponse.TablaAmortizacion.Amortizacion[] amortizacionArray)
            {
                check_orphaned();
                arraySetterHelper(amortizacionArray, AMORTIZACION$0);
            }
            
            /**
             * Sets ith "amortizacion" element
             */
            public void setAmortizacionArray(int i, edu.itq.soa.amortizacion.TablaAmortizacionResponseDocument.TablaAmortizacionResponse.TablaAmortizacion.Amortizacion amortizacion)
            {
                generatedSetterHelperImpl(amortizacion, AMORTIZACION$0, i, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_ARRAYITEM);
            }
            
            /**
             * Inserts and returns a new empty value (as xml) as the ith "amortizacion" element
             */
            public edu.itq.soa.amortizacion.TablaAmortizacionResponseDocument.TablaAmortizacionResponse.TablaAmortizacion.Amortizacion insertNewAmortizacion(int i)
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    edu.itq.soa.amortizacion.TablaAmortizacionResponseDocument.TablaAmortizacionResponse.TablaAmortizacion.Amortizacion target = null;
                    target = (edu.itq.soa.amortizacion.TablaAmortizacionResponseDocument.TablaAmortizacionResponse.TablaAmortizacion.Amortizacion)get_store().insert_element_user(AMORTIZACION$0, i);
                    return target;
                }
            }
            
            /**
             * Appends and returns a new empty value (as xml) as the last "amortizacion" element
             */
            public edu.itq.soa.amortizacion.TablaAmortizacionResponseDocument.TablaAmortizacionResponse.TablaAmortizacion.Amortizacion addNewAmortizacion()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    edu.itq.soa.amortizacion.TablaAmortizacionResponseDocument.TablaAmortizacionResponse.TablaAmortizacion.Amortizacion target = null;
                    target = (edu.itq.soa.amortizacion.TablaAmortizacionResponseDocument.TablaAmortizacionResponse.TablaAmortizacion.Amortizacion)get_store().add_element_user(AMORTIZACION$0);
                    return target;
                }
            }
            
            /**
             * Removes the ith "amortizacion" element
             */
            public void removeAmortizacion(int i)
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    get_store().remove_element(AMORTIZACION$0, i);
                }
            }
            /**
             * An XML amortizacion(@http://itq.edu/soa/amortizacion).
             *
             * This is a complex type.
             */
            public static class AmortizacionImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements edu.itq.soa.amortizacion.TablaAmortizacionResponseDocument.TablaAmortizacionResponse.TablaAmortizacion.Amortizacion
            {
                private static final long serialVersionUID = 1L;
                
                public AmortizacionImpl(org.apache.xmlbeans.SchemaType sType)
                {
                    super(sType);
                }
                
                private static final javax.xml.namespace.QName NUMPAGO$0 = 
                    new javax.xml.namespace.QName("http://itq.edu/soa/amortizacion", "numPago");
                private static final javax.xml.namespace.QName PAGOSMENSUALES$2 = 
                    new javax.xml.namespace.QName("http://itq.edu/soa/amortizacion", "pagosMensuales");
                private static final javax.xml.namespace.QName INTERESPAGO$4 = 
                    new javax.xml.namespace.QName("http://itq.edu/soa/amortizacion", "interesPago");
                private static final javax.xml.namespace.QName PRINCIPAL$6 = 
                    new javax.xml.namespace.QName("http://itq.edu/soa/amortizacion", "principal");
                private static final javax.xml.namespace.QName BALANCE$8 = 
                    new javax.xml.namespace.QName("http://itq.edu/soa/amortizacion", "balance");
                private static final javax.xml.namespace.QName INTERESESTOTALES$10 = 
                    new javax.xml.namespace.QName("http://itq.edu/soa/amortizacion", "interesesTotales");
                
                
                /**
                 * Gets the "numPago" element
                 */
                public int getNumPago()
                {
                    synchronized (monitor())
                    {
                      check_orphaned();
                      org.apache.xmlbeans.SimpleValue target = null;
                      target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NUMPAGO$0, 0);
                      if (target == null)
                      {
                        return 0;
                      }
                      return target.getIntValue();
                    }
                }
                
                /**
                 * Gets (as xml) the "numPago" element
                 */
                public org.apache.xmlbeans.XmlInt xgetNumPago()
                {
                    synchronized (monitor())
                    {
                      check_orphaned();
                      org.apache.xmlbeans.XmlInt target = null;
                      target = (org.apache.xmlbeans.XmlInt)get_store().find_element_user(NUMPAGO$0, 0);
                      return target;
                    }
                }
                
                /**
                 * Sets the "numPago" element
                 */
                public void setNumPago(int numPago)
                {
                    synchronized (monitor())
                    {
                      check_orphaned();
                      org.apache.xmlbeans.SimpleValue target = null;
                      target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NUMPAGO$0, 0);
                      if (target == null)
                      {
                        target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(NUMPAGO$0);
                      }
                      target.setIntValue(numPago);
                    }
                }
                
                /**
                 * Sets (as xml) the "numPago" element
                 */
                public void xsetNumPago(org.apache.xmlbeans.XmlInt numPago)
                {
                    synchronized (monitor())
                    {
                      check_orphaned();
                      org.apache.xmlbeans.XmlInt target = null;
                      target = (org.apache.xmlbeans.XmlInt)get_store().find_element_user(NUMPAGO$0, 0);
                      if (target == null)
                      {
                        target = (org.apache.xmlbeans.XmlInt)get_store().add_element_user(NUMPAGO$0);
                      }
                      target.set(numPago);
                    }
                }
                
                /**
                 * Gets the "pagosMensuales" element
                 */
                public double getPagosMensuales()
                {
                    synchronized (monitor())
                    {
                      check_orphaned();
                      org.apache.xmlbeans.SimpleValue target = null;
                      target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PAGOSMENSUALES$2, 0);
                      if (target == null)
                      {
                        return 0.0;
                      }
                      return target.getDoubleValue();
                    }
                }
                
                /**
                 * Gets (as xml) the "pagosMensuales" element
                 */
                public org.apache.xmlbeans.XmlDouble xgetPagosMensuales()
                {
                    synchronized (monitor())
                    {
                      check_orphaned();
                      org.apache.xmlbeans.XmlDouble target = null;
                      target = (org.apache.xmlbeans.XmlDouble)get_store().find_element_user(PAGOSMENSUALES$2, 0);
                      return target;
                    }
                }
                
                /**
                 * Sets the "pagosMensuales" element
                 */
                public void setPagosMensuales(double pagosMensuales)
                {
                    synchronized (monitor())
                    {
                      check_orphaned();
                      org.apache.xmlbeans.SimpleValue target = null;
                      target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PAGOSMENSUALES$2, 0);
                      if (target == null)
                      {
                        target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(PAGOSMENSUALES$2);
                      }
                      target.setDoubleValue(pagosMensuales);
                    }
                }
                
                /**
                 * Sets (as xml) the "pagosMensuales" element
                 */
                public void xsetPagosMensuales(org.apache.xmlbeans.XmlDouble pagosMensuales)
                {
                    synchronized (monitor())
                    {
                      check_orphaned();
                      org.apache.xmlbeans.XmlDouble target = null;
                      target = (org.apache.xmlbeans.XmlDouble)get_store().find_element_user(PAGOSMENSUALES$2, 0);
                      if (target == null)
                      {
                        target = (org.apache.xmlbeans.XmlDouble)get_store().add_element_user(PAGOSMENSUALES$2);
                      }
                      target.set(pagosMensuales);
                    }
                }
                
                /**
                 * Gets the "interesPago" element
                 */
                public double getInteresPago()
                {
                    synchronized (monitor())
                    {
                      check_orphaned();
                      org.apache.xmlbeans.SimpleValue target = null;
                      target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(INTERESPAGO$4, 0);
                      if (target == null)
                      {
                        return 0.0;
                      }
                      return target.getDoubleValue();
                    }
                }
                
                /**
                 * Gets (as xml) the "interesPago" element
                 */
                public org.apache.xmlbeans.XmlDouble xgetInteresPago()
                {
                    synchronized (monitor())
                    {
                      check_orphaned();
                      org.apache.xmlbeans.XmlDouble target = null;
                      target = (org.apache.xmlbeans.XmlDouble)get_store().find_element_user(INTERESPAGO$4, 0);
                      return target;
                    }
                }
                
                /**
                 * Sets the "interesPago" element
                 */
                public void setInteresPago(double interesPago)
                {
                    synchronized (monitor())
                    {
                      check_orphaned();
                      org.apache.xmlbeans.SimpleValue target = null;
                      target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(INTERESPAGO$4, 0);
                      if (target == null)
                      {
                        target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(INTERESPAGO$4);
                      }
                      target.setDoubleValue(interesPago);
                    }
                }
                
                /**
                 * Sets (as xml) the "interesPago" element
                 */
                public void xsetInteresPago(org.apache.xmlbeans.XmlDouble interesPago)
                {
                    synchronized (monitor())
                    {
                      check_orphaned();
                      org.apache.xmlbeans.XmlDouble target = null;
                      target = (org.apache.xmlbeans.XmlDouble)get_store().find_element_user(INTERESPAGO$4, 0);
                      if (target == null)
                      {
                        target = (org.apache.xmlbeans.XmlDouble)get_store().add_element_user(INTERESPAGO$4);
                      }
                      target.set(interesPago);
                    }
                }
                
                /**
                 * Gets the "principal" element
                 */
                public double getPrincipal()
                {
                    synchronized (monitor())
                    {
                      check_orphaned();
                      org.apache.xmlbeans.SimpleValue target = null;
                      target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PRINCIPAL$6, 0);
                      if (target == null)
                      {
                        return 0.0;
                      }
                      return target.getDoubleValue();
                    }
                }
                
                /**
                 * Gets (as xml) the "principal" element
                 */
                public org.apache.xmlbeans.XmlDouble xgetPrincipal()
                {
                    synchronized (monitor())
                    {
                      check_orphaned();
                      org.apache.xmlbeans.XmlDouble target = null;
                      target = (org.apache.xmlbeans.XmlDouble)get_store().find_element_user(PRINCIPAL$6, 0);
                      return target;
                    }
                }
                
                /**
                 * Sets the "principal" element
                 */
                public void setPrincipal(double principal)
                {
                    synchronized (monitor())
                    {
                      check_orphaned();
                      org.apache.xmlbeans.SimpleValue target = null;
                      target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PRINCIPAL$6, 0);
                      if (target == null)
                      {
                        target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(PRINCIPAL$6);
                      }
                      target.setDoubleValue(principal);
                    }
                }
                
                /**
                 * Sets (as xml) the "principal" element
                 */
                public void xsetPrincipal(org.apache.xmlbeans.XmlDouble principal)
                {
                    synchronized (monitor())
                    {
                      check_orphaned();
                      org.apache.xmlbeans.XmlDouble target = null;
                      target = (org.apache.xmlbeans.XmlDouble)get_store().find_element_user(PRINCIPAL$6, 0);
                      if (target == null)
                      {
                        target = (org.apache.xmlbeans.XmlDouble)get_store().add_element_user(PRINCIPAL$6);
                      }
                      target.set(principal);
                    }
                }
                
                /**
                 * Gets the "balance" element
                 */
                public double getBalance()
                {
                    synchronized (monitor())
                    {
                      check_orphaned();
                      org.apache.xmlbeans.SimpleValue target = null;
                      target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(BALANCE$8, 0);
                      if (target == null)
                      {
                        return 0.0;
                      }
                      return target.getDoubleValue();
                    }
                }
                
                /**
                 * Gets (as xml) the "balance" element
                 */
                public org.apache.xmlbeans.XmlDouble xgetBalance()
                {
                    synchronized (monitor())
                    {
                      check_orphaned();
                      org.apache.xmlbeans.XmlDouble target = null;
                      target = (org.apache.xmlbeans.XmlDouble)get_store().find_element_user(BALANCE$8, 0);
                      return target;
                    }
                }
                
                /**
                 * Sets the "balance" element
                 */
                public void setBalance(double balance)
                {
                    synchronized (monitor())
                    {
                      check_orphaned();
                      org.apache.xmlbeans.SimpleValue target = null;
                      target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(BALANCE$8, 0);
                      if (target == null)
                      {
                        target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(BALANCE$8);
                      }
                      target.setDoubleValue(balance);
                    }
                }
                
                /**
                 * Sets (as xml) the "balance" element
                 */
                public void xsetBalance(org.apache.xmlbeans.XmlDouble balance)
                {
                    synchronized (monitor())
                    {
                      check_orphaned();
                      org.apache.xmlbeans.XmlDouble target = null;
                      target = (org.apache.xmlbeans.XmlDouble)get_store().find_element_user(BALANCE$8, 0);
                      if (target == null)
                      {
                        target = (org.apache.xmlbeans.XmlDouble)get_store().add_element_user(BALANCE$8);
                      }
                      target.set(balance);
                    }
                }
                
                /**
                 * Gets the "interesesTotales" element
                 */
                public double getInteresesTotales()
                {
                    synchronized (monitor())
                    {
                      check_orphaned();
                      org.apache.xmlbeans.SimpleValue target = null;
                      target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(INTERESESTOTALES$10, 0);
                      if (target == null)
                      {
                        return 0.0;
                      }
                      return target.getDoubleValue();
                    }
                }
                
                /**
                 * Gets (as xml) the "interesesTotales" element
                 */
                public org.apache.xmlbeans.XmlDouble xgetInteresesTotales()
                {
                    synchronized (monitor())
                    {
                      check_orphaned();
                      org.apache.xmlbeans.XmlDouble target = null;
                      target = (org.apache.xmlbeans.XmlDouble)get_store().find_element_user(INTERESESTOTALES$10, 0);
                      return target;
                    }
                }
                
                /**
                 * Sets the "interesesTotales" element
                 */
                public void setInteresesTotales(double interesesTotales)
                {
                    synchronized (monitor())
                    {
                      check_orphaned();
                      org.apache.xmlbeans.SimpleValue target = null;
                      target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(INTERESESTOTALES$10, 0);
                      if (target == null)
                      {
                        target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(INTERESESTOTALES$10);
                      }
                      target.setDoubleValue(interesesTotales);
                    }
                }
                
                /**
                 * Sets (as xml) the "interesesTotales" element
                 */
                public void xsetInteresesTotales(org.apache.xmlbeans.XmlDouble interesesTotales)
                {
                    synchronized (monitor())
                    {
                      check_orphaned();
                      org.apache.xmlbeans.XmlDouble target = null;
                      target = (org.apache.xmlbeans.XmlDouble)get_store().find_element_user(INTERESESTOTALES$10, 0);
                      if (target == null)
                      {
                        target = (org.apache.xmlbeans.XmlDouble)get_store().add_element_user(INTERESESTOTALES$10);
                      }
                      target.set(interesesTotales);
                    }
                }
            }
        }
    }
}
