/*
 * An XML document type.
 * Localname: tablaAmortizacionRequest
 * Namespace: http://itq.edu/soa/amortizacion
 * Java type: edu.itq.soa.amortizacion.TablaAmortizacionRequestDocument
 *
 * Automatically generated - do not modify.
 */
package edu.itq.soa.amortizacion.impl;
/**
 * A document containing one tablaAmortizacionRequest(@http://itq.edu/soa/amortizacion) element.
 *
 * This is a complex type.
 */
public class TablaAmortizacionRequestDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements edu.itq.soa.amortizacion.TablaAmortizacionRequestDocument
{
    private static final long serialVersionUID = 1L;
    
    public TablaAmortizacionRequestDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName TABLAAMORTIZACIONREQUEST$0 = 
        new javax.xml.namespace.QName("http://itq.edu/soa/amortizacion", "tablaAmortizacionRequest");
    
    
    /**
     * Gets the "tablaAmortizacionRequest" element
     */
    public edu.itq.soa.amortizacion.TablaAmortizacionRequestDocument.TablaAmortizacionRequest getTablaAmortizacionRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            edu.itq.soa.amortizacion.TablaAmortizacionRequestDocument.TablaAmortizacionRequest target = null;
            target = (edu.itq.soa.amortizacion.TablaAmortizacionRequestDocument.TablaAmortizacionRequest)get_store().find_element_user(TABLAAMORTIZACIONREQUEST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "tablaAmortizacionRequest" element
     */
    public void setTablaAmortizacionRequest(edu.itq.soa.amortizacion.TablaAmortizacionRequestDocument.TablaAmortizacionRequest tablaAmortizacionRequest)
    {
        generatedSetterHelperImpl(tablaAmortizacionRequest, TABLAAMORTIZACIONREQUEST$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "tablaAmortizacionRequest" element
     */
    public edu.itq.soa.amortizacion.TablaAmortizacionRequestDocument.TablaAmortizacionRequest addNewTablaAmortizacionRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            edu.itq.soa.amortizacion.TablaAmortizacionRequestDocument.TablaAmortizacionRequest target = null;
            target = (edu.itq.soa.amortizacion.TablaAmortizacionRequestDocument.TablaAmortizacionRequest)get_store().add_element_user(TABLAAMORTIZACIONREQUEST$0);
            return target;
        }
    }
    /**
     * An XML tablaAmortizacionRequest(@http://itq.edu/soa/amortizacion).
     *
     * This is a complex type.
     */
    public static class TablaAmortizacionRequestImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements edu.itq.soa.amortizacion.TablaAmortizacionRequestDocument.TablaAmortizacionRequest
    {
        private static final long serialVersionUID = 1L;
        
        public TablaAmortizacionRequestImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName NOMBRES$0 = 
            new javax.xml.namespace.QName("http://itq.edu/soa/amortizacion", "nombres");
        private static final javax.xml.namespace.QName APELLIDOPATERNO$2 = 
            new javax.xml.namespace.QName("http://itq.edu/soa/amortizacion", "apellidoPaterno");
        private static final javax.xml.namespace.QName APELLIDOMATERNO$4 = 
            new javax.xml.namespace.QName("http://itq.edu/soa/amortizacion", "apellidoMaterno");
        private static final javax.xml.namespace.QName EMAIL$6 = 
            new javax.xml.namespace.QName("http://itq.edu/soa/amortizacion", "email");
        private static final javax.xml.namespace.QName INTERES$8 = 
            new javax.xml.namespace.QName("http://itq.edu/soa/amortizacion", "interes");
        private static final javax.xml.namespace.QName MONTO$10 = 
            new javax.xml.namespace.QName("http://itq.edu/soa/amortizacion", "monto");
        private static final javax.xml.namespace.QName MESES$12 = 
            new javax.xml.namespace.QName("http://itq.edu/soa/amortizacion", "meses");
        
        
        /**
         * Gets the "nombres" element
         */
        public java.lang.String getNombres()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NOMBRES$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target.getStringValue();
            }
        }
        
        /**
         * Gets (as xml) the "nombres" element
         */
        public org.apache.xmlbeans.XmlString xgetNombres()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlString target = null;
                target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(NOMBRES$0, 0);
                return target;
            }
        }
        
        /**
         * Sets the "nombres" element
         */
        public void setNombres(java.lang.String nombres)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NOMBRES$0, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(NOMBRES$0);
                }
                target.setStringValue(nombres);
            }
        }
        
        /**
         * Sets (as xml) the "nombres" element
         */
        public void xsetNombres(org.apache.xmlbeans.XmlString nombres)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlString target = null;
                target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(NOMBRES$0, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(NOMBRES$0);
                }
                target.set(nombres);
            }
        }
        
        /**
         * Gets the "apellidoPaterno" element
         */
        public java.lang.String getApellidoPaterno()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(APELLIDOPATERNO$2, 0);
                if (target == null)
                {
                    return null;
                }
                return target.getStringValue();
            }
        }
        
        /**
         * Gets (as xml) the "apellidoPaterno" element
         */
        public org.apache.xmlbeans.XmlString xgetApellidoPaterno()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlString target = null;
                target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(APELLIDOPATERNO$2, 0);
                return target;
            }
        }
        
        /**
         * Sets the "apellidoPaterno" element
         */
        public void setApellidoPaterno(java.lang.String apellidoPaterno)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(APELLIDOPATERNO$2, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(APELLIDOPATERNO$2);
                }
                target.setStringValue(apellidoPaterno);
            }
        }
        
        /**
         * Sets (as xml) the "apellidoPaterno" element
         */
        public void xsetApellidoPaterno(org.apache.xmlbeans.XmlString apellidoPaterno)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlString target = null;
                target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(APELLIDOPATERNO$2, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(APELLIDOPATERNO$2);
                }
                target.set(apellidoPaterno);
            }
        }
        
        /**
         * Gets the "apellidoMaterno" element
         */
        public java.lang.String getApellidoMaterno()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(APELLIDOMATERNO$4, 0);
                if (target == null)
                {
                    return null;
                }
                return target.getStringValue();
            }
        }
        
        /**
         * Gets (as xml) the "apellidoMaterno" element
         */
        public org.apache.xmlbeans.XmlString xgetApellidoMaterno()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlString target = null;
                target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(APELLIDOMATERNO$4, 0);
                return target;
            }
        }
        
        /**
         * Sets the "apellidoMaterno" element
         */
        public void setApellidoMaterno(java.lang.String apellidoMaterno)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(APELLIDOMATERNO$4, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(APELLIDOMATERNO$4);
                }
                target.setStringValue(apellidoMaterno);
            }
        }
        
        /**
         * Sets (as xml) the "apellidoMaterno" element
         */
        public void xsetApellidoMaterno(org.apache.xmlbeans.XmlString apellidoMaterno)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlString target = null;
                target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(APELLIDOMATERNO$4, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(APELLIDOMATERNO$4);
                }
                target.set(apellidoMaterno);
            }
        }
        
        /**
         * Gets the "email" element
         */
        public java.lang.String getEmail()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(EMAIL$6, 0);
                if (target == null)
                {
                    return null;
                }
                return target.getStringValue();
            }
        }
        
        /**
         * Gets (as xml) the "email" element
         */
        public edu.itq.soa.amortizacion.Email xgetEmail()
        {
            synchronized (monitor())
            {
                check_orphaned();
                edu.itq.soa.amortizacion.Email target = null;
                target = (edu.itq.soa.amortizacion.Email)get_store().find_element_user(EMAIL$6, 0);
                return target;
            }
        }
        
        /**
         * Sets the "email" element
         */
        public void setEmail(java.lang.String email)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(EMAIL$6, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(EMAIL$6);
                }
                target.setStringValue(email);
            }
        }
        
        /**
         * Sets (as xml) the "email" element
         */
        public void xsetEmail(edu.itq.soa.amortizacion.Email email)
        {
            synchronized (monitor())
            {
                check_orphaned();
                edu.itq.soa.amortizacion.Email target = null;
                target = (edu.itq.soa.amortizacion.Email)get_store().find_element_user(EMAIL$6, 0);
                if (target == null)
                {
                    target = (edu.itq.soa.amortizacion.Email)get_store().add_element_user(EMAIL$6);
                }
                target.set(email);
            }
        }
        
        /**
         * Gets the "interes" element
         */
        public double getInteres()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(INTERES$8, 0);
                if (target == null)
                {
                    return 0.0;
                }
                return target.getDoubleValue();
            }
        }
        
        /**
         * Gets (as xml) the "interes" element
         */
        public org.apache.xmlbeans.XmlDouble xgetInteres()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlDouble target = null;
                target = (org.apache.xmlbeans.XmlDouble)get_store().find_element_user(INTERES$8, 0);
                return target;
            }
        }
        
        /**
         * Sets the "interes" element
         */
        public void setInteres(double interes)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(INTERES$8, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(INTERES$8);
                }
                target.setDoubleValue(interes);
            }
        }
        
        /**
         * Sets (as xml) the "interes" element
         */
        public void xsetInteres(org.apache.xmlbeans.XmlDouble interes)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlDouble target = null;
                target = (org.apache.xmlbeans.XmlDouble)get_store().find_element_user(INTERES$8, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.XmlDouble)get_store().add_element_user(INTERES$8);
                }
                target.set(interes);
            }
        }
        
        /**
         * Gets the "monto" element
         */
        public double getMonto()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(MONTO$10, 0);
                if (target == null)
                {
                    return 0.0;
                }
                return target.getDoubleValue();
            }
        }
        
        /**
         * Gets (as xml) the "monto" element
         */
        public org.apache.xmlbeans.XmlDouble xgetMonto()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlDouble target = null;
                target = (org.apache.xmlbeans.XmlDouble)get_store().find_element_user(MONTO$10, 0);
                return target;
            }
        }
        
        /**
         * Sets the "monto" element
         */
        public void setMonto(double monto)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(MONTO$10, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(MONTO$10);
                }
                target.setDoubleValue(monto);
            }
        }
        
        /**
         * Sets (as xml) the "monto" element
         */
        public void xsetMonto(org.apache.xmlbeans.XmlDouble monto)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlDouble target = null;
                target = (org.apache.xmlbeans.XmlDouble)get_store().find_element_user(MONTO$10, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.XmlDouble)get_store().add_element_user(MONTO$10);
                }
                target.set(monto);
            }
        }
        
        /**
         * Gets the "meses" element
         */
        public int getMeses()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(MESES$12, 0);
                if (target == null)
                {
                    return 0;
                }
                return target.getIntValue();
            }
        }
        
        /**
         * Gets (as xml) the "meses" element
         */
        public org.apache.xmlbeans.XmlInt xgetMeses()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlInt target = null;
                target = (org.apache.xmlbeans.XmlInt)get_store().find_element_user(MESES$12, 0);
                return target;
            }
        }
        
        /**
         * Sets the "meses" element
         */
        public void setMeses(int meses)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(MESES$12, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(MESES$12);
                }
                target.setIntValue(meses);
            }
        }
        
        /**
         * Sets (as xml) the "meses" element
         */
        public void xsetMeses(org.apache.xmlbeans.XmlInt meses)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlInt target = null;
                target = (org.apache.xmlbeans.XmlInt)get_store().find_element_user(MESES$12, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.XmlInt)get_store().add_element_user(MESES$12);
                }
                target.set(meses);
            }
        }
    }
}
