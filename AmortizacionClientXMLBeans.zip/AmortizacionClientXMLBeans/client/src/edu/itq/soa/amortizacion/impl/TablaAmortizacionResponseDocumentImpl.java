/*
 * An XML document type.
 * Localname: tablaAmortizacionResponse
 * Namespace: http://itq.edu/soa/amortizacion
 * Java type: edu.itq.soa.amortizacion.TablaAmortizacionResponseDocument
 *
 * Automatically generated - do not modify.
 */
package edu.itq.soa.amortizacion.impl;
/**
 * A document containing one tablaAmortizacionResponse(@http://itq.edu/soa/amortizacion) element.
 *
 * This is a complex type.
 */
public class TablaAmortizacionResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements edu.itq.soa.amortizacion.TablaAmortizacionResponseDocument
{
    private static final long serialVersionUID = 1L;
    
    public TablaAmortizacionResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName TABLAAMORTIZACIONRESPONSE$0 = 
        new javax.xml.namespace.QName("http://itq.edu/soa/amortizacion", "tablaAmortizacionResponse");
    
    
    /**
     * Gets the "tablaAmortizacionResponse" element
     */
    public edu.itq.soa.amortizacion.TablaAmortizacionResponseDocument.TablaAmortizacionResponse getTablaAmortizacionResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            edu.itq.soa.amortizacion.TablaAmortizacionResponseDocument.TablaAmortizacionResponse target = null;
            target = (edu.itq.soa.amortizacion.TablaAmortizacionResponseDocument.TablaAmortizacionResponse)get_store().find_element_user(TABLAAMORTIZACIONRESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "tablaAmortizacionResponse" element
     */
    public void setTablaAmortizacionResponse(edu.itq.soa.amortizacion.TablaAmortizacionResponseDocument.TablaAmortizacionResponse tablaAmortizacionResponse)
    {
        generatedSetterHelperImpl(tablaAmortizacionResponse, TABLAAMORTIZACIONRESPONSE$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "tablaAmortizacionResponse" element
     */
    public edu.itq.soa.amortizacion.TablaAmortizacionResponseDocument.TablaAmortizacionResponse addNewTablaAmortizacionResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            edu.itq.soa.amortizacion.TablaAmortizacionResponseDocument.TablaAmortizacionResponse target = null;
            target = (edu.itq.soa.amortizacion.TablaAmortizacionResponseDocument.TablaAmortizacionResponse)get_store().add_element_user(TABLAAMORTIZACIONRESPONSE$0);
            return target;
        }
    }
    /**
     * An XML tablaAmortizacionResponse(@http://itq.edu/soa/amortizacion).
     *
     * This is a complex type.
     */
    public static class TablaAmortizacionResponseImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements edu.itq.soa.amortizacion.TablaAmortizacionResponseDocument.TablaAmortizacionResponse
    {
        private static final long serialVersionUID = 1L;
        
        public TablaAmortizacionResponseImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName NOMBRES$0 = 
            new javax.xml.namespace.QName("http://itq.edu/soa/amortizacion", "nombres");
        private static final javax.xml.namespace.QName APELLIDOPATERNO$2 = 
            new javax.xml.namespace.QName("http://itq.edu/soa/amortizacion", "apellidoPaterno");
        private static final javax.xml.namespace.QName APELLIDOMATERNO$4 = 
            new javax.xml.namespace.QName("http://itq.edu/soa/amortizacion", "apellidoMaterno");
        private static final javax.xml.namespace.QName PAGOMENSUAL$6 = 
            new javax.xml.namespace.QName("http://itq.edu/soa/amortizacion", "pagoMensual");
        private static final javax.xml.namespace.QName INTERES$8 = 
            new javax.xml.namespace.QName("http://itq.edu/soa/amortizacion", "interes");
        private static final javax.xml.namespace.QName AMORTIZACION$10 = 
            new javax.xml.namespace.QName("http://itq.edu/soa/amortizacion", "amortizacion");
        
        
        /**
         * Gets the "nombres" element
         */
        public java.lang.String getNombres()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NOMBRES$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target.getStringValue();
            }
        }
        
        /**
         * Gets (as xml) the "nombres" element
         */
        public org.apache.xmlbeans.XmlString xgetNombres()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlString target = null;
                target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(NOMBRES$0, 0);
                return target;
            }
        }
        
        /**
         * Sets the "nombres" element
         */
        public void setNombres(java.lang.String nombres)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NOMBRES$0, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(NOMBRES$0);
                }
                target.setStringValue(nombres);
            }
        }
        
        /**
         * Sets (as xml) the "nombres" element
         */
        public void xsetNombres(org.apache.xmlbeans.XmlString nombres)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlString target = null;
                target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(NOMBRES$0, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(NOMBRES$0);
                }
                target.set(nombres);
            }
        }
        
        /**
         * Gets the "apellidoPaterno" element
         */
        public java.lang.String getApellidoPaterno()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(APELLIDOPATERNO$2, 0);
                if (target == null)
                {
                    return null;
                }
                return target.getStringValue();
            }
        }
        
        /**
         * Gets (as xml) the "apellidoPaterno" element
         */
        public org.apache.xmlbeans.XmlString xgetApellidoPaterno()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlString target = null;
                target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(APELLIDOPATERNO$2, 0);
                return target;
            }
        }
        
        /**
         * Sets the "apellidoPaterno" element
         */
        public void setApellidoPaterno(java.lang.String apellidoPaterno)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(APELLIDOPATERNO$2, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(APELLIDOPATERNO$2);
                }
                target.setStringValue(apellidoPaterno);
            }
        }
        
        /**
         * Sets (as xml) the "apellidoPaterno" element
         */
        public void xsetApellidoPaterno(org.apache.xmlbeans.XmlString apellidoPaterno)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlString target = null;
                target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(APELLIDOPATERNO$2, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(APELLIDOPATERNO$2);
                }
                target.set(apellidoPaterno);
            }
        }
        
        /**
         * Gets the "apellidoMaterno" element
         */
        public java.lang.String getApellidoMaterno()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(APELLIDOMATERNO$4, 0);
                if (target == null)
                {
                    return null;
                }
                return target.getStringValue();
            }
        }
        
        /**
         * Gets (as xml) the "apellidoMaterno" element
         */
        public org.apache.xmlbeans.XmlString xgetApellidoMaterno()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlString target = null;
                target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(APELLIDOMATERNO$4, 0);
                return target;
            }
        }
        
        /**
         * Sets the "apellidoMaterno" element
         */
        public void setApellidoMaterno(java.lang.String apellidoMaterno)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(APELLIDOMATERNO$4, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(APELLIDOMATERNO$4);
                }
                target.setStringValue(apellidoMaterno);
            }
        }
        
        /**
         * Sets (as xml) the "apellidoMaterno" element
         */
        public void xsetApellidoMaterno(org.apache.xmlbeans.XmlString apellidoMaterno)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlString target = null;
                target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(APELLIDOMATERNO$4, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(APELLIDOMATERNO$4);
                }
                target.set(apellidoMaterno);
            }
        }
        
        /**
         * Gets the "pagoMensual" element
         */
        public double getPagoMensual()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PAGOMENSUAL$6, 0);
                if (target == null)
                {
                    return 0.0;
                }
                return target.getDoubleValue();
            }
        }
        
        /**
         * Gets (as xml) the "pagoMensual" element
         */
        public org.apache.xmlbeans.XmlDouble xgetPagoMensual()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlDouble target = null;
                target = (org.apache.xmlbeans.XmlDouble)get_store().find_element_user(PAGOMENSUAL$6, 0);
                return target;
            }
        }
        
        /**
         * Sets the "pagoMensual" element
         */
        public void setPagoMensual(double pagoMensual)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PAGOMENSUAL$6, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(PAGOMENSUAL$6);
                }
                target.setDoubleValue(pagoMensual);
            }
        }
        
        /**
         * Sets (as xml) the "pagoMensual" element
         */
        public void xsetPagoMensual(org.apache.xmlbeans.XmlDouble pagoMensual)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlDouble target = null;
                target = (org.apache.xmlbeans.XmlDouble)get_store().find_element_user(PAGOMENSUAL$6, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.XmlDouble)get_store().add_element_user(PAGOMENSUAL$6);
                }
                target.set(pagoMensual);
            }
        }
        
        /**
         * Gets the "interes" element
         */
        public double getInteres()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(INTERES$8, 0);
                if (target == null)
                {
                    return 0.0;
                }
                return target.getDoubleValue();
            }
        }
        
        /**
         * Gets (as xml) the "interes" element
         */
        public org.apache.xmlbeans.XmlDouble xgetInteres()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlDouble target = null;
                target = (org.apache.xmlbeans.XmlDouble)get_store().find_element_user(INTERES$8, 0);
                return target;
            }
        }
        
        /**
         * Sets the "interes" element
         */
        public void setInteres(double interes)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(INTERES$8, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(INTERES$8);
                }
                target.setDoubleValue(interes);
            }
        }
        
        /**
         * Sets (as xml) the "interes" element
         */
        public void xsetInteres(org.apache.xmlbeans.XmlDouble interes)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlDouble target = null;
                target = (org.apache.xmlbeans.XmlDouble)get_store().find_element_user(INTERES$8, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.XmlDouble)get_store().add_element_user(INTERES$8);
                }
                target.set(interes);
            }
        }
        
        /**
         * Gets the "amortizacion" element
         */
        public edu.itq.soa.amortizacion.TablaAmortizacionResponseDocument.TablaAmortizacionResponse.Amortizacion getAmortizacion()
        {
            synchronized (monitor())
            {
                check_orphaned();
                edu.itq.soa.amortizacion.TablaAmortizacionResponseDocument.TablaAmortizacionResponse.Amortizacion target = null;
                target = (edu.itq.soa.amortizacion.TablaAmortizacionResponseDocument.TablaAmortizacionResponse.Amortizacion)get_store().find_element_user(AMORTIZACION$10, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * Sets the "amortizacion" element
         */
        public void setAmortizacion(edu.itq.soa.amortizacion.TablaAmortizacionResponseDocument.TablaAmortizacionResponse.Amortizacion amortizacion)
        {
            generatedSetterHelperImpl(amortizacion, AMORTIZACION$10, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
        }
        
        /**
         * Appends and returns a new empty "amortizacion" element
         */
        public edu.itq.soa.amortizacion.TablaAmortizacionResponseDocument.TablaAmortizacionResponse.Amortizacion addNewAmortizacion()
        {
            synchronized (monitor())
            {
                check_orphaned();
                edu.itq.soa.amortizacion.TablaAmortizacionResponseDocument.TablaAmortizacionResponse.Amortizacion target = null;
                target = (edu.itq.soa.amortizacion.TablaAmortizacionResponseDocument.TablaAmortizacionResponse.Amortizacion)get_store().add_element_user(AMORTIZACION$10);
                return target;
            }
        }
        /**
         * An XML amortizacion(@http://itq.edu/soa/amortizacion).
         *
         * This is a complex type.
         */
        public static class AmortizacionImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements edu.itq.soa.amortizacion.TablaAmortizacionResponseDocument.TablaAmortizacionResponse.Amortizacion
        {
            private static final long serialVersionUID = 1L;
            
            public AmortizacionImpl(org.apache.xmlbeans.SchemaType sType)
            {
                super(sType);
            }
            
            private static final javax.xml.namespace.QName NUMPAGO$0 = 
                new javax.xml.namespace.QName("http://itq.edu/soa/amortizacion", "numPago");
            private static final javax.xml.namespace.QName PAGOSMENSUALES$2 = 
                new javax.xml.namespace.QName("http://itq.edu/soa/amortizacion", "pagosMensuales");
            private static final javax.xml.namespace.QName INTERESPAGO$4 = 
                new javax.xml.namespace.QName("http://itq.edu/soa/amortizacion", "interesPago");
            private static final javax.xml.namespace.QName PRINCIPAL$6 = 
                new javax.xml.namespace.QName("http://itq.edu/soa/amortizacion", "principal");
            private static final javax.xml.namespace.QName BALANCE$8 = 
                new javax.xml.namespace.QName("http://itq.edu/soa/amortizacion", "balance");
            private static final javax.xml.namespace.QName INTERESESTOTALES$10 = 
                new javax.xml.namespace.QName("http://itq.edu/soa/amortizacion", "interesesTotales");
            
            
            /**
             * Gets array of all "numPago" elements
             */
            public int[] getNumPagoArray()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    java.util.List targetList = new java.util.ArrayList();
                    get_store().find_all_element_users(NUMPAGO$0, targetList);
                    int[] result = new int[targetList.size()];
                    for (int i = 0, len = targetList.size() ; i < len ; i++)
                        result[i] = ((org.apache.xmlbeans.SimpleValue)targetList.get(i)).getIntValue();
                    return result;
                }
            }
            
            /**
             * Gets ith "numPago" element
             */
            public int getNumPagoArray(int i)
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.apache.xmlbeans.SimpleValue target = null;
                    target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NUMPAGO$0, i);
                    if (target == null)
                    {
                      throw new IndexOutOfBoundsException();
                    }
                    return target.getIntValue();
                }
            }
            
            /**
             * Gets (as xml) array of all "numPago" elements
             */
            public org.apache.xmlbeans.XmlInt[] xgetNumPagoArray()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    java.util.List targetList = new java.util.ArrayList();
                    get_store().find_all_element_users(NUMPAGO$0, targetList);
                    org.apache.xmlbeans.XmlInt[] result = new org.apache.xmlbeans.XmlInt[targetList.size()];
                    targetList.toArray(result);
                    return result;
                }
            }
            
            /**
             * Gets (as xml) ith "numPago" element
             */
            public org.apache.xmlbeans.XmlInt xgetNumPagoArray(int i)
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.apache.xmlbeans.XmlInt target = null;
                    target = (org.apache.xmlbeans.XmlInt)get_store().find_element_user(NUMPAGO$0, i);
                    if (target == null)
                    {
                      throw new IndexOutOfBoundsException();
                    }
                    return target;
                }
            }
            
            /**
             * Returns number of "numPago" element
             */
            public int sizeOfNumPagoArray()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    return get_store().count_elements(NUMPAGO$0);
                }
            }
            
            /**
             * Sets array of all "numPago" element
             */
            public void setNumPagoArray(int[] numPagoArray)
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    arraySetterHelper(numPagoArray, NUMPAGO$0);
                }
            }
            
            /**
             * Sets ith "numPago" element
             */
            public void setNumPagoArray(int i, int numPago)
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.apache.xmlbeans.SimpleValue target = null;
                    target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NUMPAGO$0, i);
                    if (target == null)
                    {
                      throw new IndexOutOfBoundsException();
                    }
                    target.setIntValue(numPago);
                }
            }
            
            /**
             * Sets (as xml) array of all "numPago" element
             */
            public void xsetNumPagoArray(org.apache.xmlbeans.XmlInt[]numPagoArray)
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    arraySetterHelper(numPagoArray, NUMPAGO$0);
                }
            }
            
            /**
             * Sets (as xml) ith "numPago" element
             */
            public void xsetNumPagoArray(int i, org.apache.xmlbeans.XmlInt numPago)
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.apache.xmlbeans.XmlInt target = null;
                    target = (org.apache.xmlbeans.XmlInt)get_store().find_element_user(NUMPAGO$0, i);
                    if (target == null)
                    {
                      throw new IndexOutOfBoundsException();
                    }
                    target.set(numPago);
                }
            }
            
            /**
             * Inserts the value as the ith "numPago" element
             */
            public void insertNumPago(int i, int numPago)
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.apache.xmlbeans.SimpleValue target = 
                      (org.apache.xmlbeans.SimpleValue)get_store().insert_element_user(NUMPAGO$0, i);
                    target.setIntValue(numPago);
                }
            }
            
            /**
             * Appends the value as the last "numPago" element
             */
            public void addNumPago(int numPago)
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.apache.xmlbeans.SimpleValue target = null;
                    target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(NUMPAGO$0);
                    target.setIntValue(numPago);
                }
            }
            
            /**
             * Inserts and returns a new empty value (as xml) as the ith "numPago" element
             */
            public org.apache.xmlbeans.XmlInt insertNewNumPago(int i)
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.apache.xmlbeans.XmlInt target = null;
                    target = (org.apache.xmlbeans.XmlInt)get_store().insert_element_user(NUMPAGO$0, i);
                    return target;
                }
            }
            
            /**
             * Appends and returns a new empty value (as xml) as the last "numPago" element
             */
            public org.apache.xmlbeans.XmlInt addNewNumPago()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.apache.xmlbeans.XmlInt target = null;
                    target = (org.apache.xmlbeans.XmlInt)get_store().add_element_user(NUMPAGO$0);
                    return target;
                }
            }
            
            /**
             * Removes the ith "numPago" element
             */
            public void removeNumPago(int i)
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    get_store().remove_element(NUMPAGO$0, i);
                }
            }
            
            /**
             * Gets array of all "pagosMensuales" elements
             */
            public double[] getPagosMensualesArray()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    java.util.List targetList = new java.util.ArrayList();
                    get_store().find_all_element_users(PAGOSMENSUALES$2, targetList);
                    double[] result = new double[targetList.size()];
                    for (int i = 0, len = targetList.size() ; i < len ; i++)
                        result[i] = ((org.apache.xmlbeans.SimpleValue)targetList.get(i)).getDoubleValue();
                    return result;
                }
            }
            
            /**
             * Gets ith "pagosMensuales" element
             */
            public double getPagosMensualesArray(int i)
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.apache.xmlbeans.SimpleValue target = null;
                    target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PAGOSMENSUALES$2, i);
                    if (target == null)
                    {
                      throw new IndexOutOfBoundsException();
                    }
                    return target.getDoubleValue();
                }
            }
            
            /**
             * Gets (as xml) array of all "pagosMensuales" elements
             */
            public org.apache.xmlbeans.XmlDouble[] xgetPagosMensualesArray()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    java.util.List targetList = new java.util.ArrayList();
                    get_store().find_all_element_users(PAGOSMENSUALES$2, targetList);
                    org.apache.xmlbeans.XmlDouble[] result = new org.apache.xmlbeans.XmlDouble[targetList.size()];
                    targetList.toArray(result);
                    return result;
                }
            }
            
            /**
             * Gets (as xml) ith "pagosMensuales" element
             */
            public org.apache.xmlbeans.XmlDouble xgetPagosMensualesArray(int i)
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.apache.xmlbeans.XmlDouble target = null;
                    target = (org.apache.xmlbeans.XmlDouble)get_store().find_element_user(PAGOSMENSUALES$2, i);
                    if (target == null)
                    {
                      throw new IndexOutOfBoundsException();
                    }
                    return target;
                }
            }
            
            /**
             * Returns number of "pagosMensuales" element
             */
            public int sizeOfPagosMensualesArray()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    return get_store().count_elements(PAGOSMENSUALES$2);
                }
            }
            
            /**
             * Sets array of all "pagosMensuales" element
             */
            public void setPagosMensualesArray(double[] pagosMensualesArray)
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    arraySetterHelper(pagosMensualesArray, PAGOSMENSUALES$2);
                }
            }
            
            /**
             * Sets ith "pagosMensuales" element
             */
            public void setPagosMensualesArray(int i, double pagosMensuales)
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.apache.xmlbeans.SimpleValue target = null;
                    target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PAGOSMENSUALES$2, i);
                    if (target == null)
                    {
                      throw new IndexOutOfBoundsException();
                    }
                    target.setDoubleValue(pagosMensuales);
                }
            }
            
            /**
             * Sets (as xml) array of all "pagosMensuales" element
             */
            public void xsetPagosMensualesArray(org.apache.xmlbeans.XmlDouble[]pagosMensualesArray)
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    arraySetterHelper(pagosMensualesArray, PAGOSMENSUALES$2);
                }
            }
            
            /**
             * Sets (as xml) ith "pagosMensuales" element
             */
            public void xsetPagosMensualesArray(int i, org.apache.xmlbeans.XmlDouble pagosMensuales)
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.apache.xmlbeans.XmlDouble target = null;
                    target = (org.apache.xmlbeans.XmlDouble)get_store().find_element_user(PAGOSMENSUALES$2, i);
                    if (target == null)
                    {
                      throw new IndexOutOfBoundsException();
                    }
                    target.set(pagosMensuales);
                }
            }
            
            /**
             * Inserts the value as the ith "pagosMensuales" element
             */
            public void insertPagosMensuales(int i, double pagosMensuales)
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.apache.xmlbeans.SimpleValue target = 
                      (org.apache.xmlbeans.SimpleValue)get_store().insert_element_user(PAGOSMENSUALES$2, i);
                    target.setDoubleValue(pagosMensuales);
                }
            }
            
            /**
             * Appends the value as the last "pagosMensuales" element
             */
            public void addPagosMensuales(double pagosMensuales)
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.apache.xmlbeans.SimpleValue target = null;
                    target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(PAGOSMENSUALES$2);
                    target.setDoubleValue(pagosMensuales);
                }
            }
            
            /**
             * Inserts and returns a new empty value (as xml) as the ith "pagosMensuales" element
             */
            public org.apache.xmlbeans.XmlDouble insertNewPagosMensuales(int i)
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.apache.xmlbeans.XmlDouble target = null;
                    target = (org.apache.xmlbeans.XmlDouble)get_store().insert_element_user(PAGOSMENSUALES$2, i);
                    return target;
                }
            }
            
            /**
             * Appends and returns a new empty value (as xml) as the last "pagosMensuales" element
             */
            public org.apache.xmlbeans.XmlDouble addNewPagosMensuales()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.apache.xmlbeans.XmlDouble target = null;
                    target = (org.apache.xmlbeans.XmlDouble)get_store().add_element_user(PAGOSMENSUALES$2);
                    return target;
                }
            }
            
            /**
             * Removes the ith "pagosMensuales" element
             */
            public void removePagosMensuales(int i)
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    get_store().remove_element(PAGOSMENSUALES$2, i);
                }
            }
            
            /**
             * Gets array of all "interesPago" elements
             */
            public double[] getInteresPagoArray()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    java.util.List targetList = new java.util.ArrayList();
                    get_store().find_all_element_users(INTERESPAGO$4, targetList);
                    double[] result = new double[targetList.size()];
                    for (int i = 0, len = targetList.size() ; i < len ; i++)
                        result[i] = ((org.apache.xmlbeans.SimpleValue)targetList.get(i)).getDoubleValue();
                    return result;
                }
            }
            
            /**
             * Gets ith "interesPago" element
             */
            public double getInteresPagoArray(int i)
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.apache.xmlbeans.SimpleValue target = null;
                    target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(INTERESPAGO$4, i);
                    if (target == null)
                    {
                      throw new IndexOutOfBoundsException();
                    }
                    return target.getDoubleValue();
                }
            }
            
            /**
             * Gets (as xml) array of all "interesPago" elements
             */
            public org.apache.xmlbeans.XmlDouble[] xgetInteresPagoArray()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    java.util.List targetList = new java.util.ArrayList();
                    get_store().find_all_element_users(INTERESPAGO$4, targetList);
                    org.apache.xmlbeans.XmlDouble[] result = new org.apache.xmlbeans.XmlDouble[targetList.size()];
                    targetList.toArray(result);
                    return result;
                }
            }
            
            /**
             * Gets (as xml) ith "interesPago" element
             */
            public org.apache.xmlbeans.XmlDouble xgetInteresPagoArray(int i)
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.apache.xmlbeans.XmlDouble target = null;
                    target = (org.apache.xmlbeans.XmlDouble)get_store().find_element_user(INTERESPAGO$4, i);
                    if (target == null)
                    {
                      throw new IndexOutOfBoundsException();
                    }
                    return target;
                }
            }
            
            /**
             * Returns number of "interesPago" element
             */
            public int sizeOfInteresPagoArray()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    return get_store().count_elements(INTERESPAGO$4);
                }
            }
            
            /**
             * Sets array of all "interesPago" element
             */
            public void setInteresPagoArray(double[] interesPagoArray)
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    arraySetterHelper(interesPagoArray, INTERESPAGO$4);
                }
            }
            
            /**
             * Sets ith "interesPago" element
             */
            public void setInteresPagoArray(int i, double interesPago)
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.apache.xmlbeans.SimpleValue target = null;
                    target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(INTERESPAGO$4, i);
                    if (target == null)
                    {
                      throw new IndexOutOfBoundsException();
                    }
                    target.setDoubleValue(interesPago);
                }
            }
            
            /**
             * Sets (as xml) array of all "interesPago" element
             */
            public void xsetInteresPagoArray(org.apache.xmlbeans.XmlDouble[]interesPagoArray)
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    arraySetterHelper(interesPagoArray, INTERESPAGO$4);
                }
            }
            
            /**
             * Sets (as xml) ith "interesPago" element
             */
            public void xsetInteresPagoArray(int i, org.apache.xmlbeans.XmlDouble interesPago)
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.apache.xmlbeans.XmlDouble target = null;
                    target = (org.apache.xmlbeans.XmlDouble)get_store().find_element_user(INTERESPAGO$4, i);
                    if (target == null)
                    {
                      throw new IndexOutOfBoundsException();
                    }
                    target.set(interesPago);
                }
            }
            
            /**
             * Inserts the value as the ith "interesPago" element
             */
            public void insertInteresPago(int i, double interesPago)
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.apache.xmlbeans.SimpleValue target = 
                      (org.apache.xmlbeans.SimpleValue)get_store().insert_element_user(INTERESPAGO$4, i);
                    target.setDoubleValue(interesPago);
                }
            }
            
            /**
             * Appends the value as the last "interesPago" element
             */
            public void addInteresPago(double interesPago)
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.apache.xmlbeans.SimpleValue target = null;
                    target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(INTERESPAGO$4);
                    target.setDoubleValue(interesPago);
                }
            }
            
            /**
             * Inserts and returns a new empty value (as xml) as the ith "interesPago" element
             */
            public org.apache.xmlbeans.XmlDouble insertNewInteresPago(int i)
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.apache.xmlbeans.XmlDouble target = null;
                    target = (org.apache.xmlbeans.XmlDouble)get_store().insert_element_user(INTERESPAGO$4, i);
                    return target;
                }
            }
            
            /**
             * Appends and returns a new empty value (as xml) as the last "interesPago" element
             */
            public org.apache.xmlbeans.XmlDouble addNewInteresPago()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.apache.xmlbeans.XmlDouble target = null;
                    target = (org.apache.xmlbeans.XmlDouble)get_store().add_element_user(INTERESPAGO$4);
                    return target;
                }
            }
            
            /**
             * Removes the ith "interesPago" element
             */
            public void removeInteresPago(int i)
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    get_store().remove_element(INTERESPAGO$4, i);
                }
            }
            
            /**
             * Gets array of all "principal" elements
             */
            public double[] getPrincipalArray()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    java.util.List targetList = new java.util.ArrayList();
                    get_store().find_all_element_users(PRINCIPAL$6, targetList);
                    double[] result = new double[targetList.size()];
                    for (int i = 0, len = targetList.size() ; i < len ; i++)
                        result[i] = ((org.apache.xmlbeans.SimpleValue)targetList.get(i)).getDoubleValue();
                    return result;
                }
            }
            
            /**
             * Gets ith "principal" element
             */
            public double getPrincipalArray(int i)
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.apache.xmlbeans.SimpleValue target = null;
                    target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PRINCIPAL$6, i);
                    if (target == null)
                    {
                      throw new IndexOutOfBoundsException();
                    }
                    return target.getDoubleValue();
                }
            }
            
            /**
             * Gets (as xml) array of all "principal" elements
             */
            public org.apache.xmlbeans.XmlDouble[] xgetPrincipalArray()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    java.util.List targetList = new java.util.ArrayList();
                    get_store().find_all_element_users(PRINCIPAL$6, targetList);
                    org.apache.xmlbeans.XmlDouble[] result = new org.apache.xmlbeans.XmlDouble[targetList.size()];
                    targetList.toArray(result);
                    return result;
                }
            }
            
            /**
             * Gets (as xml) ith "principal" element
             */
            public org.apache.xmlbeans.XmlDouble xgetPrincipalArray(int i)
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.apache.xmlbeans.XmlDouble target = null;
                    target = (org.apache.xmlbeans.XmlDouble)get_store().find_element_user(PRINCIPAL$6, i);
                    if (target == null)
                    {
                      throw new IndexOutOfBoundsException();
                    }
                    return target;
                }
            }
            
            /**
             * Returns number of "principal" element
             */
            public int sizeOfPrincipalArray()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    return get_store().count_elements(PRINCIPAL$6);
                }
            }
            
            /**
             * Sets array of all "principal" element
             */
            public void setPrincipalArray(double[] principalArray)
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    arraySetterHelper(principalArray, PRINCIPAL$6);
                }
            }
            
            /**
             * Sets ith "principal" element
             */
            public void setPrincipalArray(int i, double principal)
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.apache.xmlbeans.SimpleValue target = null;
                    target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PRINCIPAL$6, i);
                    if (target == null)
                    {
                      throw new IndexOutOfBoundsException();
                    }
                    target.setDoubleValue(principal);
                }
            }
            
            /**
             * Sets (as xml) array of all "principal" element
             */
            public void xsetPrincipalArray(org.apache.xmlbeans.XmlDouble[]principalArray)
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    arraySetterHelper(principalArray, PRINCIPAL$6);
                }
            }
            
            /**
             * Sets (as xml) ith "principal" element
             */
            public void xsetPrincipalArray(int i, org.apache.xmlbeans.XmlDouble principal)
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.apache.xmlbeans.XmlDouble target = null;
                    target = (org.apache.xmlbeans.XmlDouble)get_store().find_element_user(PRINCIPAL$6, i);
                    if (target == null)
                    {
                      throw new IndexOutOfBoundsException();
                    }
                    target.set(principal);
                }
            }
            
            /**
             * Inserts the value as the ith "principal" element
             */
            public void insertPrincipal(int i, double principal)
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.apache.xmlbeans.SimpleValue target = 
                      (org.apache.xmlbeans.SimpleValue)get_store().insert_element_user(PRINCIPAL$6, i);
                    target.setDoubleValue(principal);
                }
            }
            
            /**
             * Appends the value as the last "principal" element
             */
            public void addPrincipal(double principal)
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.apache.xmlbeans.SimpleValue target = null;
                    target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(PRINCIPAL$6);
                    target.setDoubleValue(principal);
                }
            }
            
            /**
             * Inserts and returns a new empty value (as xml) as the ith "principal" element
             */
            public org.apache.xmlbeans.XmlDouble insertNewPrincipal(int i)
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.apache.xmlbeans.XmlDouble target = null;
                    target = (org.apache.xmlbeans.XmlDouble)get_store().insert_element_user(PRINCIPAL$6, i);
                    return target;
                }
            }
            
            /**
             * Appends and returns a new empty value (as xml) as the last "principal" element
             */
            public org.apache.xmlbeans.XmlDouble addNewPrincipal()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.apache.xmlbeans.XmlDouble target = null;
                    target = (org.apache.xmlbeans.XmlDouble)get_store().add_element_user(PRINCIPAL$6);
                    return target;
                }
            }
            
            /**
             * Removes the ith "principal" element
             */
            public void removePrincipal(int i)
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    get_store().remove_element(PRINCIPAL$6, i);
                }
            }
            
            /**
             * Gets array of all "balance" elements
             */
            public double[] getBalanceArray()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    java.util.List targetList = new java.util.ArrayList();
                    get_store().find_all_element_users(BALANCE$8, targetList);
                    double[] result = new double[targetList.size()];
                    for (int i = 0, len = targetList.size() ; i < len ; i++)
                        result[i] = ((org.apache.xmlbeans.SimpleValue)targetList.get(i)).getDoubleValue();
                    return result;
                }
            }
            
            /**
             * Gets ith "balance" element
             */
            public double getBalanceArray(int i)
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.apache.xmlbeans.SimpleValue target = null;
                    target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(BALANCE$8, i);
                    if (target == null)
                    {
                      throw new IndexOutOfBoundsException();
                    }
                    return target.getDoubleValue();
                }
            }
            
            /**
             * Gets (as xml) array of all "balance" elements
             */
            public org.apache.xmlbeans.XmlDouble[] xgetBalanceArray()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    java.util.List targetList = new java.util.ArrayList();
                    get_store().find_all_element_users(BALANCE$8, targetList);
                    org.apache.xmlbeans.XmlDouble[] result = new org.apache.xmlbeans.XmlDouble[targetList.size()];
                    targetList.toArray(result);
                    return result;
                }
            }
            
            /**
             * Gets (as xml) ith "balance" element
             */
            public org.apache.xmlbeans.XmlDouble xgetBalanceArray(int i)
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.apache.xmlbeans.XmlDouble target = null;
                    target = (org.apache.xmlbeans.XmlDouble)get_store().find_element_user(BALANCE$8, i);
                    if (target == null)
                    {
                      throw new IndexOutOfBoundsException();
                    }
                    return target;
                }
            }
            
            /**
             * Returns number of "balance" element
             */
            public int sizeOfBalanceArray()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    return get_store().count_elements(BALANCE$8);
                }
            }
            
            /**
             * Sets array of all "balance" element
             */
            public void setBalanceArray(double[] balanceArray)
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    arraySetterHelper(balanceArray, BALANCE$8);
                }
            }
            
            /**
             * Sets ith "balance" element
             */
            public void setBalanceArray(int i, double balance)
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.apache.xmlbeans.SimpleValue target = null;
                    target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(BALANCE$8, i);
                    if (target == null)
                    {
                      throw new IndexOutOfBoundsException();
                    }
                    target.setDoubleValue(balance);
                }
            }
            
            /**
             * Sets (as xml) array of all "balance" element
             */
            public void xsetBalanceArray(org.apache.xmlbeans.XmlDouble[]balanceArray)
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    arraySetterHelper(balanceArray, BALANCE$8);
                }
            }
            
            /**
             * Sets (as xml) ith "balance" element
             */
            public void xsetBalanceArray(int i, org.apache.xmlbeans.XmlDouble balance)
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.apache.xmlbeans.XmlDouble target = null;
                    target = (org.apache.xmlbeans.XmlDouble)get_store().find_element_user(BALANCE$8, i);
                    if (target == null)
                    {
                      throw new IndexOutOfBoundsException();
                    }
                    target.set(balance);
                }
            }
            
            /**
             * Inserts the value as the ith "balance" element
             */
            public void insertBalance(int i, double balance)
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.apache.xmlbeans.SimpleValue target = 
                      (org.apache.xmlbeans.SimpleValue)get_store().insert_element_user(BALANCE$8, i);
                    target.setDoubleValue(balance);
                }
            }
            
            /**
             * Appends the value as the last "balance" element
             */
            public void addBalance(double balance)
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.apache.xmlbeans.SimpleValue target = null;
                    target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(BALANCE$8);
                    target.setDoubleValue(balance);
                }
            }
            
            /**
             * Inserts and returns a new empty value (as xml) as the ith "balance" element
             */
            public org.apache.xmlbeans.XmlDouble insertNewBalance(int i)
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.apache.xmlbeans.XmlDouble target = null;
                    target = (org.apache.xmlbeans.XmlDouble)get_store().insert_element_user(BALANCE$8, i);
                    return target;
                }
            }
            
            /**
             * Appends and returns a new empty value (as xml) as the last "balance" element
             */
            public org.apache.xmlbeans.XmlDouble addNewBalance()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.apache.xmlbeans.XmlDouble target = null;
                    target = (org.apache.xmlbeans.XmlDouble)get_store().add_element_user(BALANCE$8);
                    return target;
                }
            }
            
            /**
             * Removes the ith "balance" element
             */
            public void removeBalance(int i)
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    get_store().remove_element(BALANCE$8, i);
                }
            }
            
            /**
             * Gets array of all "interesesTotales" elements
             */
            public double[] getInteresesTotalesArray()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    java.util.List targetList = new java.util.ArrayList();
                    get_store().find_all_element_users(INTERESESTOTALES$10, targetList);
                    double[] result = new double[targetList.size()];
                    for (int i = 0, len = targetList.size() ; i < len ; i++)
                        result[i] = ((org.apache.xmlbeans.SimpleValue)targetList.get(i)).getDoubleValue();
                    return result;
                }
            }
            
            /**
             * Gets ith "interesesTotales" element
             */
            public double getInteresesTotalesArray(int i)
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.apache.xmlbeans.SimpleValue target = null;
                    target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(INTERESESTOTALES$10, i);
                    if (target == null)
                    {
                      throw new IndexOutOfBoundsException();
                    }
                    return target.getDoubleValue();
                }
            }
            
            /**
             * Gets (as xml) array of all "interesesTotales" elements
             */
            public org.apache.xmlbeans.XmlDouble[] xgetInteresesTotalesArray()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    java.util.List targetList = new java.util.ArrayList();
                    get_store().find_all_element_users(INTERESESTOTALES$10, targetList);
                    org.apache.xmlbeans.XmlDouble[] result = new org.apache.xmlbeans.XmlDouble[targetList.size()];
                    targetList.toArray(result);
                    return result;
                }
            }
            
            /**
             * Gets (as xml) ith "interesesTotales" element
             */
            public org.apache.xmlbeans.XmlDouble xgetInteresesTotalesArray(int i)
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.apache.xmlbeans.XmlDouble target = null;
                    target = (org.apache.xmlbeans.XmlDouble)get_store().find_element_user(INTERESESTOTALES$10, i);
                    if (target == null)
                    {
                      throw new IndexOutOfBoundsException();
                    }
                    return target;
                }
            }
            
            /**
             * Returns number of "interesesTotales" element
             */
            public int sizeOfInteresesTotalesArray()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    return get_store().count_elements(INTERESESTOTALES$10);
                }
            }
            
            /**
             * Sets array of all "interesesTotales" element
             */
            public void setInteresesTotalesArray(double[] interesesTotalesArray)
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    arraySetterHelper(interesesTotalesArray, INTERESESTOTALES$10);
                }
            }
            
            /**
             * Sets ith "interesesTotales" element
             */
            public void setInteresesTotalesArray(int i, double interesesTotales)
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.apache.xmlbeans.SimpleValue target = null;
                    target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(INTERESESTOTALES$10, i);
                    if (target == null)
                    {
                      throw new IndexOutOfBoundsException();
                    }
                    target.setDoubleValue(interesesTotales);
                }
            }
            
            /**
             * Sets (as xml) array of all "interesesTotales" element
             */
            public void xsetInteresesTotalesArray(org.apache.xmlbeans.XmlDouble[]interesesTotalesArray)
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    arraySetterHelper(interesesTotalesArray, INTERESESTOTALES$10);
                }
            }
            
            /**
             * Sets (as xml) ith "interesesTotales" element
             */
            public void xsetInteresesTotalesArray(int i, org.apache.xmlbeans.XmlDouble interesesTotales)
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.apache.xmlbeans.XmlDouble target = null;
                    target = (org.apache.xmlbeans.XmlDouble)get_store().find_element_user(INTERESESTOTALES$10, i);
                    if (target == null)
                    {
                      throw new IndexOutOfBoundsException();
                    }
                    target.set(interesesTotales);
                }
            }
            
            /**
             * Inserts the value as the ith "interesesTotales" element
             */
            public void insertInteresesTotales(int i, double interesesTotales)
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.apache.xmlbeans.SimpleValue target = 
                      (org.apache.xmlbeans.SimpleValue)get_store().insert_element_user(INTERESESTOTALES$10, i);
                    target.setDoubleValue(interesesTotales);
                }
            }
            
            /**
             * Appends the value as the last "interesesTotales" element
             */
            public void addInteresesTotales(double interesesTotales)
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.apache.xmlbeans.SimpleValue target = null;
                    target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(INTERESESTOTALES$10);
                    target.setDoubleValue(interesesTotales);
                }
            }
            
            /**
             * Inserts and returns a new empty value (as xml) as the ith "interesesTotales" element
             */
            public org.apache.xmlbeans.XmlDouble insertNewInteresesTotales(int i)
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.apache.xmlbeans.XmlDouble target = null;
                    target = (org.apache.xmlbeans.XmlDouble)get_store().insert_element_user(INTERESESTOTALES$10, i);
                    return target;
                }
            }
            
            /**
             * Appends and returns a new empty value (as xml) as the last "interesesTotales" element
             */
            public org.apache.xmlbeans.XmlDouble addNewInteresesTotales()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.apache.xmlbeans.XmlDouble target = null;
                    target = (org.apache.xmlbeans.XmlDouble)get_store().add_element_user(INTERESESTOTALES$10);
                    return target;
                }
            }
            
            /**
             * Removes the ith "interesesTotales" element
             */
            public void removeInteresesTotales(int i)
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    get_store().remove_element(INTERESESTOTALES$10, i);
                }
            }
        }
    }
}
