/*
 * An XML document type.
 * Localname: tablaAmortizacionResponse
 * Namespace: http://itq.edu/soa/amortizacion
 * Java type: edu.itq.soa.amortizacion.TablaAmortizacionResponseDocument
 *
 * Automatically generated - do not modify.
 */
package edu.itq.soa.amortizacion;


/**
 * A document containing one tablaAmortizacionResponse(@http://itq.edu/soa/amortizacion) element.
 *
 * This is a complex type.
 */
public interface TablaAmortizacionResponseDocument extends org.apache.xmlbeans.XmlObject
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(TablaAmortizacionResponseDocument.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s01FB4C69ED8EF3D55381EF55FD68269C").resolveHandle("tablaamortizacionresponse2cefdoctype");
    
    /**
     * Gets the "tablaAmortizacionResponse" element
     */
    edu.itq.soa.amortizacion.TablaAmortizacionResponseDocument.TablaAmortizacionResponse getTablaAmortizacionResponse();
    
    /**
     * Sets the "tablaAmortizacionResponse" element
     */
    void setTablaAmortizacionResponse(edu.itq.soa.amortizacion.TablaAmortizacionResponseDocument.TablaAmortizacionResponse tablaAmortizacionResponse);
    
    /**
     * Appends and returns a new empty "tablaAmortizacionResponse" element
     */
    edu.itq.soa.amortizacion.TablaAmortizacionResponseDocument.TablaAmortizacionResponse addNewTablaAmortizacionResponse();
    
    /**
     * An XML tablaAmortizacionResponse(@http://itq.edu/soa/amortizacion).
     *
     * This is a complex type.
     */
    public interface TablaAmortizacionResponse extends org.apache.xmlbeans.XmlObject
    {
        public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
            org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(TablaAmortizacionResponse.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s01FB4C69ED8EF3D55381EF55FD68269C").resolveHandle("tablaamortizacionresponsee156elemtype");
        
        /**
         * Gets the "nombres" element
         */
        java.lang.String getNombres();
        
        /**
         * Gets (as xml) the "nombres" element
         */
        org.apache.xmlbeans.XmlString xgetNombres();
        
        /**
         * Sets the "nombres" element
         */
        void setNombres(java.lang.String nombres);
        
        /**
         * Sets (as xml) the "nombres" element
         */
        void xsetNombres(org.apache.xmlbeans.XmlString nombres);
        
        /**
         * Gets the "apellidoPaterno" element
         */
        java.lang.String getApellidoPaterno();
        
        /**
         * Gets (as xml) the "apellidoPaterno" element
         */
        org.apache.xmlbeans.XmlString xgetApellidoPaterno();
        
        /**
         * Sets the "apellidoPaterno" element
         */
        void setApellidoPaterno(java.lang.String apellidoPaterno);
        
        /**
         * Sets (as xml) the "apellidoPaterno" element
         */
        void xsetApellidoPaterno(org.apache.xmlbeans.XmlString apellidoPaterno);
        
        /**
         * Gets the "apellidoMaterno" element
         */
        java.lang.String getApellidoMaterno();
        
        /**
         * Gets (as xml) the "apellidoMaterno" element
         */
        org.apache.xmlbeans.XmlString xgetApellidoMaterno();
        
        /**
         * Sets the "apellidoMaterno" element
         */
        void setApellidoMaterno(java.lang.String apellidoMaterno);
        
        /**
         * Sets (as xml) the "apellidoMaterno" element
         */
        void xsetApellidoMaterno(org.apache.xmlbeans.XmlString apellidoMaterno);
        
        /**
         * Gets the "pagoMensual" element
         */
        double getPagoMensual();
        
        /**
         * Gets (as xml) the "pagoMensual" element
         */
        org.apache.xmlbeans.XmlDouble xgetPagoMensual();
        
        /**
         * Sets the "pagoMensual" element
         */
        void setPagoMensual(double pagoMensual);
        
        /**
         * Sets (as xml) the "pagoMensual" element
         */
        void xsetPagoMensual(org.apache.xmlbeans.XmlDouble pagoMensual);
        
        /**
         * Gets the "interes" element
         */
        double getInteres();
        
        /**
         * Gets (as xml) the "interes" element
         */
        org.apache.xmlbeans.XmlDouble xgetInteres();
        
        /**
         * Sets the "interes" element
         */
        void setInteres(double interes);
        
        /**
         * Sets (as xml) the "interes" element
         */
        void xsetInteres(org.apache.xmlbeans.XmlDouble interes);
        
        /**
         * Gets the "amortizacion" element
         */
        edu.itq.soa.amortizacion.TablaAmortizacionResponseDocument.TablaAmortizacionResponse.Amortizacion getAmortizacion();
        
        /**
         * Sets the "amortizacion" element
         */
        void setAmortizacion(edu.itq.soa.amortizacion.TablaAmortizacionResponseDocument.TablaAmortizacionResponse.Amortizacion amortizacion);
        
        /**
         * Appends and returns a new empty "amortizacion" element
         */
        edu.itq.soa.amortizacion.TablaAmortizacionResponseDocument.TablaAmortizacionResponse.Amortizacion addNewAmortizacion();
        
        /**
         * An XML amortizacion(@http://itq.edu/soa/amortizacion).
         *
         * This is a complex type.
         */
        public interface Amortizacion extends org.apache.xmlbeans.XmlObject
        {
            public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
                org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(Amortizacion.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s01FB4C69ED8EF3D55381EF55FD68269C").resolveHandle("amortizacion6122elemtype");
            
            /**
             * Gets array of all "numPago" elements
             */
            int[] getNumPagoArray();
            
            /**
             * Gets ith "numPago" element
             */
            int getNumPagoArray(int i);
            
            /**
             * Gets (as xml) array of all "numPago" elements
             */
            org.apache.xmlbeans.XmlInt[] xgetNumPagoArray();
            
            /**
             * Gets (as xml) ith "numPago" element
             */
            org.apache.xmlbeans.XmlInt xgetNumPagoArray(int i);
            
            /**
             * Returns number of "numPago" element
             */
            int sizeOfNumPagoArray();
            
            /**
             * Sets array of all "numPago" element
             */
            void setNumPagoArray(int[] numPagoArray);
            
            /**
             * Sets ith "numPago" element
             */
            void setNumPagoArray(int i, int numPago);
            
            /**
             * Sets (as xml) array of all "numPago" element
             */
            void xsetNumPagoArray(org.apache.xmlbeans.XmlInt[] numPagoArray);
            
            /**
             * Sets (as xml) ith "numPago" element
             */
            void xsetNumPagoArray(int i, org.apache.xmlbeans.XmlInt numPago);
            
            /**
             * Inserts the value as the ith "numPago" element
             */
            void insertNumPago(int i, int numPago);
            
            /**
             * Appends the value as the last "numPago" element
             */
            void addNumPago(int numPago);
            
            /**
             * Inserts and returns a new empty value (as xml) as the ith "numPago" element
             */
            org.apache.xmlbeans.XmlInt insertNewNumPago(int i);
            
            /**
             * Appends and returns a new empty value (as xml) as the last "numPago" element
             */
            org.apache.xmlbeans.XmlInt addNewNumPago();
            
            /**
             * Removes the ith "numPago" element
             */
            void removeNumPago(int i);
            
            /**
             * Gets array of all "pagosMensuales" elements
             */
            double[] getPagosMensualesArray();
            
            /**
             * Gets ith "pagosMensuales" element
             */
            double getPagosMensualesArray(int i);
            
            /**
             * Gets (as xml) array of all "pagosMensuales" elements
             */
            org.apache.xmlbeans.XmlDouble[] xgetPagosMensualesArray();
            
            /**
             * Gets (as xml) ith "pagosMensuales" element
             */
            org.apache.xmlbeans.XmlDouble xgetPagosMensualesArray(int i);
            
            /**
             * Returns number of "pagosMensuales" element
             */
            int sizeOfPagosMensualesArray();
            
            /**
             * Sets array of all "pagosMensuales" element
             */
            void setPagosMensualesArray(double[] pagosMensualesArray);
            
            /**
             * Sets ith "pagosMensuales" element
             */
            void setPagosMensualesArray(int i, double pagosMensuales);
            
            /**
             * Sets (as xml) array of all "pagosMensuales" element
             */
            void xsetPagosMensualesArray(org.apache.xmlbeans.XmlDouble[] pagosMensualesArray);
            
            /**
             * Sets (as xml) ith "pagosMensuales" element
             */
            void xsetPagosMensualesArray(int i, org.apache.xmlbeans.XmlDouble pagosMensuales);
            
            /**
             * Inserts the value as the ith "pagosMensuales" element
             */
            void insertPagosMensuales(int i, double pagosMensuales);
            
            /**
             * Appends the value as the last "pagosMensuales" element
             */
            void addPagosMensuales(double pagosMensuales);
            
            /**
             * Inserts and returns a new empty value (as xml) as the ith "pagosMensuales" element
             */
            org.apache.xmlbeans.XmlDouble insertNewPagosMensuales(int i);
            
            /**
             * Appends and returns a new empty value (as xml) as the last "pagosMensuales" element
             */
            org.apache.xmlbeans.XmlDouble addNewPagosMensuales();
            
            /**
             * Removes the ith "pagosMensuales" element
             */
            void removePagosMensuales(int i);
            
            /**
             * Gets array of all "interesPago" elements
             */
            double[] getInteresPagoArray();
            
            /**
             * Gets ith "interesPago" element
             */
            double getInteresPagoArray(int i);
            
            /**
             * Gets (as xml) array of all "interesPago" elements
             */
            org.apache.xmlbeans.XmlDouble[] xgetInteresPagoArray();
            
            /**
             * Gets (as xml) ith "interesPago" element
             */
            org.apache.xmlbeans.XmlDouble xgetInteresPagoArray(int i);
            
            /**
             * Returns number of "interesPago" element
             */
            int sizeOfInteresPagoArray();
            
            /**
             * Sets array of all "interesPago" element
             */
            void setInteresPagoArray(double[] interesPagoArray);
            
            /**
             * Sets ith "interesPago" element
             */
            void setInteresPagoArray(int i, double interesPago);
            
            /**
             * Sets (as xml) array of all "interesPago" element
             */
            void xsetInteresPagoArray(org.apache.xmlbeans.XmlDouble[] interesPagoArray);
            
            /**
             * Sets (as xml) ith "interesPago" element
             */
            void xsetInteresPagoArray(int i, org.apache.xmlbeans.XmlDouble interesPago);
            
            /**
             * Inserts the value as the ith "interesPago" element
             */
            void insertInteresPago(int i, double interesPago);
            
            /**
             * Appends the value as the last "interesPago" element
             */
            void addInteresPago(double interesPago);
            
            /**
             * Inserts and returns a new empty value (as xml) as the ith "interesPago" element
             */
            org.apache.xmlbeans.XmlDouble insertNewInteresPago(int i);
            
            /**
             * Appends and returns a new empty value (as xml) as the last "interesPago" element
             */
            org.apache.xmlbeans.XmlDouble addNewInteresPago();
            
            /**
             * Removes the ith "interesPago" element
             */
            void removeInteresPago(int i);
            
            /**
             * Gets array of all "principal" elements
             */
            double[] getPrincipalArray();
            
            /**
             * Gets ith "principal" element
             */
            double getPrincipalArray(int i);
            
            /**
             * Gets (as xml) array of all "principal" elements
             */
            org.apache.xmlbeans.XmlDouble[] xgetPrincipalArray();
            
            /**
             * Gets (as xml) ith "principal" element
             */
            org.apache.xmlbeans.XmlDouble xgetPrincipalArray(int i);
            
            /**
             * Returns number of "principal" element
             */
            int sizeOfPrincipalArray();
            
            /**
             * Sets array of all "principal" element
             */
            void setPrincipalArray(double[] principalArray);
            
            /**
             * Sets ith "principal" element
             */
            void setPrincipalArray(int i, double principal);
            
            /**
             * Sets (as xml) array of all "principal" element
             */
            void xsetPrincipalArray(org.apache.xmlbeans.XmlDouble[] principalArray);
            
            /**
             * Sets (as xml) ith "principal" element
             */
            void xsetPrincipalArray(int i, org.apache.xmlbeans.XmlDouble principal);
            
            /**
             * Inserts the value as the ith "principal" element
             */
            void insertPrincipal(int i, double principal);
            
            /**
             * Appends the value as the last "principal" element
             */
            void addPrincipal(double principal);
            
            /**
             * Inserts and returns a new empty value (as xml) as the ith "principal" element
             */
            org.apache.xmlbeans.XmlDouble insertNewPrincipal(int i);
            
            /**
             * Appends and returns a new empty value (as xml) as the last "principal" element
             */
            org.apache.xmlbeans.XmlDouble addNewPrincipal();
            
            /**
             * Removes the ith "principal" element
             */
            void removePrincipal(int i);
            
            /**
             * Gets array of all "balance" elements
             */
            double[] getBalanceArray();
            
            /**
             * Gets ith "balance" element
             */
            double getBalanceArray(int i);
            
            /**
             * Gets (as xml) array of all "balance" elements
             */
            org.apache.xmlbeans.XmlDouble[] xgetBalanceArray();
            
            /**
             * Gets (as xml) ith "balance" element
             */
            org.apache.xmlbeans.XmlDouble xgetBalanceArray(int i);
            
            /**
             * Returns number of "balance" element
             */
            int sizeOfBalanceArray();
            
            /**
             * Sets array of all "balance" element
             */
            void setBalanceArray(double[] balanceArray);
            
            /**
             * Sets ith "balance" element
             */
            void setBalanceArray(int i, double balance);
            
            /**
             * Sets (as xml) array of all "balance" element
             */
            void xsetBalanceArray(org.apache.xmlbeans.XmlDouble[] balanceArray);
            
            /**
             * Sets (as xml) ith "balance" element
             */
            void xsetBalanceArray(int i, org.apache.xmlbeans.XmlDouble balance);
            
            /**
             * Inserts the value as the ith "balance" element
             */
            void insertBalance(int i, double balance);
            
            /**
             * Appends the value as the last "balance" element
             */
            void addBalance(double balance);
            
            /**
             * Inserts and returns a new empty value (as xml) as the ith "balance" element
             */
            org.apache.xmlbeans.XmlDouble insertNewBalance(int i);
            
            /**
             * Appends and returns a new empty value (as xml) as the last "balance" element
             */
            org.apache.xmlbeans.XmlDouble addNewBalance();
            
            /**
             * Removes the ith "balance" element
             */
            void removeBalance(int i);
            
            /**
             * Gets array of all "interesesTotales" elements
             */
            double[] getInteresesTotalesArray();
            
            /**
             * Gets ith "interesesTotales" element
             */
            double getInteresesTotalesArray(int i);
            
            /**
             * Gets (as xml) array of all "interesesTotales" elements
             */
            org.apache.xmlbeans.XmlDouble[] xgetInteresesTotalesArray();
            
            /**
             * Gets (as xml) ith "interesesTotales" element
             */
            org.apache.xmlbeans.XmlDouble xgetInteresesTotalesArray(int i);
            
            /**
             * Returns number of "interesesTotales" element
             */
            int sizeOfInteresesTotalesArray();
            
            /**
             * Sets array of all "interesesTotales" element
             */
            void setInteresesTotalesArray(double[] interesesTotalesArray);
            
            /**
             * Sets ith "interesesTotales" element
             */
            void setInteresesTotalesArray(int i, double interesesTotales);
            
            /**
             * Sets (as xml) array of all "interesesTotales" element
             */
            void xsetInteresesTotalesArray(org.apache.xmlbeans.XmlDouble[] interesesTotalesArray);
            
            /**
             * Sets (as xml) ith "interesesTotales" element
             */
            void xsetInteresesTotalesArray(int i, org.apache.xmlbeans.XmlDouble interesesTotales);
            
            /**
             * Inserts the value as the ith "interesesTotales" element
             */
            void insertInteresesTotales(int i, double interesesTotales);
            
            /**
             * Appends the value as the last "interesesTotales" element
             */
            void addInteresesTotales(double interesesTotales);
            
            /**
             * Inserts and returns a new empty value (as xml) as the ith "interesesTotales" element
             */
            org.apache.xmlbeans.XmlDouble insertNewInteresesTotales(int i);
            
            /**
             * Appends and returns a new empty value (as xml) as the last "interesesTotales" element
             */
            org.apache.xmlbeans.XmlDouble addNewInteresesTotales();
            
            /**
             * Removes the ith "interesesTotales" element
             */
            void removeInteresesTotales(int i);
            
            /**
             * A factory class with static methods for creating instances
             * of this type.
             */
            
            public static final class Factory
            {
                public static edu.itq.soa.amortizacion.TablaAmortizacionResponseDocument.TablaAmortizacionResponse.Amortizacion newInstance() {
                  return (edu.itq.soa.amortizacion.TablaAmortizacionResponseDocument.TablaAmortizacionResponse.Amortizacion) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
                
                public static edu.itq.soa.amortizacion.TablaAmortizacionResponseDocument.TablaAmortizacionResponse.Amortizacion newInstance(org.apache.xmlbeans.XmlOptions options) {
                  return (edu.itq.soa.amortizacion.TablaAmortizacionResponseDocument.TablaAmortizacionResponse.Amortizacion) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
                
                private Factory() { } // No instance of this class allowed
            }
        }
        
        /**
         * A factory class with static methods for creating instances
         * of this type.
         */
        
        public static final class Factory
        {
            public static edu.itq.soa.amortizacion.TablaAmortizacionResponseDocument.TablaAmortizacionResponse newInstance() {
              return (edu.itq.soa.amortizacion.TablaAmortizacionResponseDocument.TablaAmortizacionResponse) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
            
            public static edu.itq.soa.amortizacion.TablaAmortizacionResponseDocument.TablaAmortizacionResponse newInstance(org.apache.xmlbeans.XmlOptions options) {
              return (edu.itq.soa.amortizacion.TablaAmortizacionResponseDocument.TablaAmortizacionResponse) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
            
            private Factory() { } // No instance of this class allowed
        }
    }
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static edu.itq.soa.amortizacion.TablaAmortizacionResponseDocument newInstance() {
          return (edu.itq.soa.amortizacion.TablaAmortizacionResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static edu.itq.soa.amortizacion.TablaAmortizacionResponseDocument newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (edu.itq.soa.amortizacion.TablaAmortizacionResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static edu.itq.soa.amortizacion.TablaAmortizacionResponseDocument parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (edu.itq.soa.amortizacion.TablaAmortizacionResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static edu.itq.soa.amortizacion.TablaAmortizacionResponseDocument parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (edu.itq.soa.amortizacion.TablaAmortizacionResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static edu.itq.soa.amortizacion.TablaAmortizacionResponseDocument parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (edu.itq.soa.amortizacion.TablaAmortizacionResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static edu.itq.soa.amortizacion.TablaAmortizacionResponseDocument parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (edu.itq.soa.amortizacion.TablaAmortizacionResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static edu.itq.soa.amortizacion.TablaAmortizacionResponseDocument parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (edu.itq.soa.amortizacion.TablaAmortizacionResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static edu.itq.soa.amortizacion.TablaAmortizacionResponseDocument parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (edu.itq.soa.amortizacion.TablaAmortizacionResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static edu.itq.soa.amortizacion.TablaAmortizacionResponseDocument parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (edu.itq.soa.amortizacion.TablaAmortizacionResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static edu.itq.soa.amortizacion.TablaAmortizacionResponseDocument parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (edu.itq.soa.amortizacion.TablaAmortizacionResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static edu.itq.soa.amortizacion.TablaAmortizacionResponseDocument parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (edu.itq.soa.amortizacion.TablaAmortizacionResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static edu.itq.soa.amortizacion.TablaAmortizacionResponseDocument parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (edu.itq.soa.amortizacion.TablaAmortizacionResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static edu.itq.soa.amortizacion.TablaAmortizacionResponseDocument parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (edu.itq.soa.amortizacion.TablaAmortizacionResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static edu.itq.soa.amortizacion.TablaAmortizacionResponseDocument parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (edu.itq.soa.amortizacion.TablaAmortizacionResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static edu.itq.soa.amortizacion.TablaAmortizacionResponseDocument parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (edu.itq.soa.amortizacion.TablaAmortizacionResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static edu.itq.soa.amortizacion.TablaAmortizacionResponseDocument parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (edu.itq.soa.amortizacion.TablaAmortizacionResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static edu.itq.soa.amortizacion.TablaAmortizacionResponseDocument parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (edu.itq.soa.amortizacion.TablaAmortizacionResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static edu.itq.soa.amortizacion.TablaAmortizacionResponseDocument parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (edu.itq.soa.amortizacion.TablaAmortizacionResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
